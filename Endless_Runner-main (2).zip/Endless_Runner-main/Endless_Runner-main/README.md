# Endless Runner

A three-lane 3D desert endless runner built with Unity and C# for Windows PC.

## Open the project

1. Install Unity **6000.3.23f1** (Unity 6.3 LTS).
2. Clone this repository, then in Unity Hub choose **Add project from disk** and select the repository root.
3. Allow Unity to restore packages and import assets.
4. Open `Assets/EndlessRunner/Scenes/EndlessRunner.unity` and press Play.

## Controls

- A/D or Left/Right Arrow: change one lane per press.
- Space/W/Up Arrow: jump.
- S/Down Arrow: slide.
- Escape: pause/resume.

## Features

- Recycled desert track, randomized obstacles and collectibles.
- Easy, Normal and Fast difficulty modes.
- Coins, gems, magnet, shield, speed boost, score multiplier and instant coin bonus.
- Animated character, audio and a delayed knockout sequence.
- Menus, HUD, pause, retry and one revive per run.
- Desert Camp, upgrades, achievements, daily missions and local leaderboard.
- Local saved progression through PlayerPrefs.

## Source layout

- `Assets/EndlessRunner/Runtime`: gameplay C# scripts.
- `Assets/EndlessRunner/Editor`: setup and build utilities.
- `Assets/EndlessRunner/Scenes`: main scene.
- `Assets`: character, prefabs, materials, fonts and other project assets.
- `Packages`: package manifest and lockfile.
- `ProjectSettings`: Unity configuration.

## Windows build

Use **Endless Runner > Build Windows** in the Unity Editor. Build output is generated locally and is excluded from source control. Do not run the baseline Create Game Scene command to open the existing game.

## Scope

This version targets Windows keyboard controls and a desert environment. The leaderboard and saved progress are local. Ads, in-app purchases, online accounts and mobile builds are not implemented.

Generated Unity caches, local preferences, personal saves and Windows build binaries are not included. Asset metadata files are included to preserve Unity references. Retain the license notices shipped with third-party assets.
