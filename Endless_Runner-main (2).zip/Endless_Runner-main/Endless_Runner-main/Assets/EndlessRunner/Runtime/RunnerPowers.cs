using UnityEngine;

namespace EndlessRunner
{
    public enum PowerKind { Magnet, Shield, Boost, Multiplier, CoinBonus }
    public sealed class RunnerPowers
    {
        readonly RunnerGame game;
        readonly float[] remaining=new float[4];
        public RunnerPowers(RunnerGame owner){game=owner;}
        public bool Magnet=>remaining[0]>0;
        public bool Shield=>remaining[1]>0;
        public bool Boost=>remaining[2]>0;
        public int Multiplier=>remaining[3]>0?2:1;
        public float Remaining(PowerKind kind)=>(int)kind<4?remaining[(int)kind]:0;
        public void Activate(PowerKind kind)
        {
            if(game.State!=RunState.Running)return;
            if(kind==PowerKind.CoinBonus)game.AwardCoins(game.coinBonus);
            else
            {
                int upgrade=kind==PowerKind.Magnet?game.Progress.Data.magnetLevel:kind==PowerKind.Shield?game.Progress.Data.shieldLevel:game.Progress.Data.durationLevel;
                remaining[(int)kind]=game.powerDuration+upgrade*2;
            }
            game.Audio.Play("power");game.Track.Burst(game.Player.transform.position+Vector3.up,game.palette[5]);game.UI.UpdateHUD();
        }
        public void Tick(float dt)
        {
            for(int i=0;i<4;i++)if(remaining[i]>0){remaining[i]=Mathf.Max(0,remaining[i]-dt);if(remaining[i]==0)game.Audio.Play("expire");}
        }
        public bool Absorb(){if(!Shield)return false;remaining[1]=0;game.Audio.Play("shield");return true;}
        public void Reset(){System.Array.Clear(remaining,0,remaining.Length);}
        public string Status()
        {
            string s="";string[] labels={"MAGNET","SHIELD 1 HIT","BOOST","SCORE x2"};
            for(int i=0;i<4;i++)if(remaining[i]>0)s+=labels[i]+"  "+Mathf.CeilToInt(remaining[i])+"s     ";
            return s.Length==0?"POWER-UPS   M magnet   S shield   B boost   x2 score   + coin bonus":s;
        }
    }
    public sealed class RunnerContact : MonoBehaviour
    {
        public System.Action Contact;
        void OnTriggerEnter(Collider other){if(other.GetComponent<RunnerAvatar>())Contact?.Invoke();}
    }
}
