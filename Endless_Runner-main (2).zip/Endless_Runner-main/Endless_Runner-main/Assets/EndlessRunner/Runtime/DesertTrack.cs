using System.Collections.Generic;
using UnityEngine;

namespace EndlessRunner
{
    public sealed class DesertTrack : MonoBehaviour
    {
        sealed class Item { public Transform visual; public bool gem, hazard, active; public Vector3 size,center; public int power=-1; public GameObject[] variants; public BoxCollider collider; }
        sealed class Chunk { public Transform root; public readonly List<Item> items = new List<Item>(); public Renderer sand; public readonly List<DesertPatternPlanner.Row> plans = new List<DesertPatternPlanner.Row>(); }
        sealed class Spark { public Transform root; public Vector3 velocity; public float life; }
        readonly List<Chunk> chunks = new List<Chunk>();
        readonly List<Spark> sparks = new List<Spark>();
        RunnerGame game;
        DesertPatternPlanner planner;
        public int RunSeed {get;private set;}
        public string LastHit {get;private set;}
        public List<DesertPatternPlanner.Row> CurrentPlans(){var result=new List<DesertPatternPlanner.Row>();foreach(var c in chunks)result.AddRange(c.plans);return result;}
        int generated;
        
        Mesh mesaMesh;
        public int Recycled { get; private set; }
        public int ChunkCount => chunks.Count;
        const float Length = 48;
        public void Initialize(RunnerGame owner)
        {
            game = owner;
            mesaMesh = CreateMesaMesh();
            var floor = new GameObject("Invisible collision floor").AddComponent<BoxCollider>(); floor.transform.SetParent(transform); floor.center = new Vector3(0, -.5f, 0); floor.size = new Vector3(12, 1, 40);
            for(int i = 0; i < 7; i++)
            {
                var c = new Chunk { root = new GameObject("Track Segment " + i).transform }; c.root.SetParent(transform);
                c.sand = Shape("Sand", PrimitiveType.Cube, c.root, new Vector3(0, -.18f, 24), new Vector3(160, .3f, 48), 0).GetComponent<Renderer>();
                Shape("Runner trail", PrimitiveType.Cube, c.root, new Vector3(0, -.012f, 24), new Vector3(11, .025f, 48), 1);
                for(int lane = -1; lane <= 1; lane += 2)
                    for(int z=0; z<48; z+=6) Shape("Trail markers", PrimitiveType.Cube, c.root, new Vector3(lane * 5.5f, .015f, z), new Vector3(.1f, .025f, 2), 8);
                for(int row = 0; row < 3; row++)
                {
                    for(int h=0;h<2;h++)
                    {
                        var root=new GameObject("Pooled obstacle slot");root.transform.SetParent(c.root,false);
                        var item=new Item{visual=root.transform,hazard=true,variants=new GameObject[game.obstaclePrefabs.Length]};
                        for(int v=0;v<item.variants.Length;v++){item.variants[v]=Instantiate(game.obstaclePrefabs[v],root.transform);item.variants[v].GetComponent<BoxCollider>().enabled=false;item.variants[v].SetActive(false);}
                        Bind(item);c.items.Add(item);
                    }
                    for(int n=0; n<5; n++)
                    {
                        bool gem = n == 4;
                        var coin = Shape(gem ? "Gem" : "Coin", gem ? PrimitiveType.Cube : PrimitiveType.Cylinder, c.root, Vector3.zero, gem ? Vector3.one * .55f : new Vector3(.65f, .08f, .65f), gem ? 5 : 4);
                        coin.transform.localRotation = gem ? Quaternion.Euler(45,0,45) : Quaternion.Euler(90,0,0);
                        var item=new Item { visual = coin.transform, gem = gem, size = Vector3.one * .7f };Bind(item);c.items.Add(item);
                    }
                }
                var powerRoot=new GameObject("Power-up pickup");powerRoot.transform.SetParent(c.root,false);
                Shape("Power crystal",PrimitiveType.Sphere,powerRoot.transform,Vector3.zero,Vector3.one*.9f,5);
                var power=new Item{visual=powerRoot.transform,size=Vector3.one*1.1f,power=0};Bind(power);c.items.Add(power);
                var label=new GameObject("Power symbol",typeof(TMPro.TextMeshPro));label.transform.SetParent(powerRoot.transform,false);label.transform.localPosition=new Vector3(0,.1f,-.52f);
                var text=label.GetComponent<TMPro.TextMeshPro>();text.font=game.font;text.fontSize=5;text.alignment=TMPro.TextAlignmentOptions.Center;text.color=Color.white;text.text="M";text.rectTransform.sizeDelta=new Vector2(1,1);
                DesertScenery.Build(c.root,i,game.palette);
                chunks.Add(c);
            }
            for(int i=0;i<36;i++) { var s=Shape("Collection sparkle",PrimitiveType.Cube,transform,Vector3.zero,Vector3.one*.13f,4); s.SetActive(false); sparks.Add(new Spark {root=s.transform}); }
        }
        void Bind(Item item)
        {
            // Pickup meshes may be scaled/rotated; use an unscaled parent for their trigger.
            if(!item.hazard){var root=new GameObject(item.visual.name+" trigger").transform;root.SetParent(item.visual.parent,false);item.visual.SetParent(root,false);item.visual=root;}
            item.collider=item.visual.gameObject.AddComponent<BoxCollider>();item.collider.isTrigger=true;item.collider.size=item.size;
            var body=item.visual.gameObject.AddComponent<Rigidbody>();body.isKinematic=true;body.useGravity=false;
            item.visual.gameObject.AddComponent<RunnerContact>().Contact=()=>{ // Recycled kinematic triggers can deliver a callback from a previous physics pose.
                var current=new Bounds(item.visual.position+item.center,item.size);
                if(current.Intersects(game.Player.HitBounds))Resolve(item,"trigger");
            };
        }
        void Variant(Item item,int index)
        {
            for(int i=0;i<item.variants.Length;i++)item.variants[i].SetActive(i==index);
            var source=item.variants[index].GetComponent<BoxCollider>();item.size=source.size;item.center=source.center;item.collider.size=item.size;item.collider.center=item.center;
        }
        void Resolve(Item item,string via="sweep")
        {
            if(!item.active||game.State!=RunState.Running)return;
            if(item.hazard)LastHit=via+" item="+item.visual.position+" center="+item.center+" size="+item.size+" player="+game.Player.HitBounds;
            item.active=false;item.visual.gameObject.SetActive(false);
            if(item.hazard)game.HitObstacle();else if(item.power>=0)game.Powers.Activate((PowerKind)item.power);else game.Collect(item.gem,item.visual.position);
        }
        static Mesh CreateMesaMesh()
        {
            var verts=new List<Vector3>();var indices=new List<int>();
            System.Action<Vector3,Vector3,Vector3> tri=(a,b,c)=>{int n=verts.Count;verts.Add(a);verts.Add(b);verts.Add(c);indices.Add(n);indices.Add(n+1);indices.Add(n+2);};
            for(int i=0;i<7;i++)
            {
                float a=i*Mathf.PI*2/7,b=(i+1)*Mathf.PI*2/7;
                var p=new Vector3(Mathf.Cos(a),0,Mathf.Sin(a));var q=new Vector3(Mathf.Cos(b),0,Mathf.Sin(b));
                var topP=new Vector3(p.x*.46f,1,p.z*.46f);var topQ=new Vector3(q.x*.46f,1,q.z*.46f);
                tri(p,topP,q);tri(q,topP,topQ);tri(topP,Vector3.up,topQ);
            }
            var mesh=new Mesh{name="Procedural sandstone mesa"};mesh.SetVertices(verts);mesh.SetTriangles(indices,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        void OnDestroy(){if(mesaMesh)Destroy(mesaMesh);}
        GameObject Shape(string name, PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, int mat) => RunnerAvatar.Shape(name,type,parent,pos,scale,game.palette[mat]);
        Transform MakeCactus(Transform parent, Vector3 position, float scale)
        {
            var root = new GameObject("Cactus").transform; root.SetParent(parent,false); root.localPosition=position; root.localScale=Vector3.one*scale;
            Shape("Stem",PrimitiveType.Capsule,root,new Vector3(0,1.4f,0),new Vector3(.55f,1.4f,.55f),10);
            Shape("Left arm",PrimitiveType.Cube,root,new Vector3(-.48f,1.4f,0),new Vector3(.8f,.3f,.32f),10);
            Shape("Left tip",PrimitiveType.Capsule,root,new Vector3(-.8f,1.8f,0),new Vector3(.3f,.5f,.3f),10);
            Shape("Right arm",PrimitiveType.Cube,root,new Vector3(.45f,1.9f,0),new Vector3(.7f,.3f,.32f),10);
            Shape("Right tip",PrimitiveType.Capsule,root,new Vector3(.7f,2.2f,0),new Vector3(.3f,.4f,.3f),10);
            return root;
        }
        public void ResetTrack(int stage,int? seed=null)
        {
            LastHit=null; RunSeed=seed??System.BitConverter.ToInt32(System.Guid.NewGuid().ToByteArray(),0);
            planner=new DesertPatternPlanner(stage,RunSeed,game.boostFactor,game.Player.lateralSpeed,game.Player.jumpSpeed,game.Player.gravity);generated=0;Recycled=0;
            foreach(var c in chunks){c.root.localPosition=new Vector3(0,0,(generated-1)*Length);Populate(c,false);generated++;}
            foreach(var s in sparks){s.life=0;s.root.gameObject.SetActive(false);}
        }
        void Populate(Chunk c,bool intro)
        {
            c.sand.sharedMaterial=game.palette[0];c.plans.Clear();
            foreach(var item in c.items){item.active=false;item.visual.gameObject.SetActive(false);}
            float segmentStart=(generated-1)*Length,segmentEnd=segmentStart+Length;
            int slot=0;
            while(planner.NextDistance<segmentEnd)
            {
                var row=planner.Next();
                if(row.Distance<segmentStart)continue;
                if(slot>=3)throw new System.InvalidOperationException("Difficulty gap exceeds pooled row capacity");
                c.plans.Add(row);int offset=slot*7;
                for(int h=0;h<row.HazardCount;h++)
                {
                    var item=c.items[offset+h];Variant(item,row.HazardTypes[h]);item.visual.localPosition=new Vector3((row.HazardLanes[h]-1)*3,0,row.Distance-segmentStart);item.active=true;item.visual.gameObject.SetActive(true);
                }
                for(int n=0;n<5;n++)
                {
                    var item=c.items[offset+2+n];bool active=n<4?n<row.CoinCount:row.Gem;
                    item.visual.localPosition=row.Coins[n]-Vector3.forward*segmentStart;item.active=active;item.visual.gameObject.SetActive(active);
                }
                slot++;
            }
            var power=c.items[21];power.power=(generated+4)%5;power.visual.localPosition=new Vector3((planner.LastSafeLane-1)*3,1.3f,44.5f);power.active=generated>1&&generated%2==0;power.visual.gameObject.SetActive(power.active);
            power.visual.GetComponentInChildren<TMPro.TMP_Text>(true).text=new[]{"M","S","B","x2","+"+game.coinBonus}[power.power];
        }
        public void Tick(float travel,float dt)
        {
            foreach(var c in chunks)c.root.position+=Vector3.back*travel;
            foreach(var c in chunks)
            {
                foreach(var item in c.items)
                {
                    if(!item.active) continue;
                    if(!item.hazard&&item.power<0) item.visual.GetChild(0).Rotate(Vector3.up,100*dt,Space.World);
                    if(!item.hazard&&!item.gem&&item.power<0&&game.Powers.Magnet&&Vector3.Distance(item.visual.position,game.Player.transform.position+Vector3.up)<game.magnetRadius)
                        item.visual.position=Vector3.MoveTowards(item.visual.position,game.Player.transform.position+Vector3.up,22*dt);
                    Vector3 center=item.visual.position+item.center;
                    // Sweep the entire travel interval so high speed cannot skip a collision.
                    var swept=new Bounds(center+Vector3.forward*travel*.5f,item.size+Vector3.forward*travel);
                    if(!swept.Intersects(game.Player.HitBounds)) continue;
                    Resolve(item);
                }
            }
            foreach(var c in chunks) if(c.root.position.z < -Length-12)
            {
                float front=float.MinValue; foreach(var other in chunks) front=Mathf.Max(front,other.root.position.z);
                c.root.position=new Vector3(0,0,front+Length); Populate(c,false); generated++; Recycled++;
            }
            foreach(var s in sparks) if(s.life>0) {s.life-=dt; s.root.position+=s.velocity*dt; s.velocity+=Vector3.down*dt*3; s.root.localScale=Vector3.one*Mathf.Max(0,s.life)*.22f; if(s.life<=0)s.root.gameObject.SetActive(false);}
        }
        public void ClearNearPlayer(float distance)
        {
            foreach(var c in chunks)foreach(var item in c.items)if(item.hazard&&Mathf.Abs(item.visual.position.z)<distance){item.active=false;item.visual.gameObject.SetActive(false);}
        }
        public void Burst(Vector3 position,Material mat)
        {
            int count=0; foreach(var s in sparks) if(s.life<=0) {s.life=.65f;s.root.position=position;s.root.gameObject.SetActive(true);s.root.GetComponent<Renderer>().sharedMaterial=mat;s.velocity=Random.onUnitSphere*2+Vector3.up; if(++count==9)break;}
        }
#if UNITY_EDITOR
        public void ClearTestItems() { foreach(var c in chunks)foreach(var i in c.items){i.active=false;i.visual.gameObject.SetActive(false);} }
        public void PlaceTestItem(bool hazard,bool gem,Vector3 position)
        {
            foreach(var c in chunks)foreach(var i in c.items)if(i.hazard==hazard && (hazard || (i.power<0&&i.gem==gem))){if(hazard)Variant(i,0);i.active=true;i.visual.gameObject.SetActive(true);i.visual.position=position-i.center;return;}
        }
        public void PlaceTestCactus(Vector3 position)
        {
            foreach(var c in chunks)foreach(var i in c.items)if(i.hazard){Variant(i,1);i.active=true;i.visual.gameObject.SetActive(true);i.visual.position=position;return;}
        }
        public void PlaceTestPower(PowerKind kind,Vector3 position){foreach(var c in chunks)foreach(var i in c.items)if(i.power>=0){i.power=(int)kind;i.active=true;i.visual.gameObject.SetActive(true);i.visual.position=position;return;}}
        public bool SpacingValid()
        {
            var positions=new List<float>();foreach(var c in chunks)positions.Add(c.root.position.z);positions.Sort();
            for(int i=1;i<positions.Count;i++)if(Mathf.Abs(positions[i]-positions[i-1]-Length)>.05f)return false;return true;
        }
#endif
    }
}






