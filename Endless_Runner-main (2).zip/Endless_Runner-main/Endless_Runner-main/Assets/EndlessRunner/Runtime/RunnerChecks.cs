#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace EndlessRunner
{
    public static class RunnerChecks
    {
        public static string Run()
        {
            var g=UnityEngine.Object.FindFirstObjectByType<RunnerGame>();
            if(!g)throw new Exception("Game not running");
            int originalBest=PlayerPrefs.GetInt("EndlessRunner.Best",0);
            string originalProgress=PlayerPrefs.GetString(RunnerProgress.SaveKey,"");
            var results=new List<string>();g.enabled=false;
            Action<bool,string> check=(ok,name)=>{results.Add((ok?"PASS ":"FAIL ")+name);};
            Action<int,float,bool> step=(frames,axis,jump)=>{for(int i=0;i<frames;i++){Physics.SyncTransforms();g.Advance(axis,jump&&i==0,1f/60);}};
            try
            {
                g.ShowMenu();check(g.State==RunState.Menu,"Main menu");
                var play=UnityEngine.Object.FindObjectsByType<UnityEngine.UI.Button>(FindObjectsSortMode.None).First(b=>b.name=="PLAY");play.onClick.Invoke();check(g.State==RunState.Stages,"Play button opens stage selection");
                g.StartRun(0);g.Track.ClearTestItems();step(60,0,false);check(Mathf.Abs(g.Distance-g.Difficulty.StartSpeed)<.1f,"Easy first-second travel matches its configured starting speed");
                step(90,1,false);check(Mathf.Abs(g.Player.transform.position.x-3f)<.05f,"Right movement and boundary");
                step(150,-1,false);check(Mathf.Abs(g.Player.transform.position.x+3f)<.05f,"Left movement and boundary");
                g.StartRun(0);g.Track.ClearTestItems();step(5,0,false);step(12,0,true);check(g.Player.transform.position.y>1,"Jump rises");
                step(100,0,false);check(g.Player.transform.position.y<.15f && g.Player.Grounded,"Gravity and landing");
                g.Track.PlaceTestItem(false,false,new Vector3(0,1,1));step(10,0,false);check(g.Coins==1,"Coin collision increments coin count");
                g.Track.PlaceTestItem(false,true,new Vector3(0,1,1));step(10,0,false);check(g.Gems==1,"Gem collision increments gem count");
                check(g.Score==Mathf.FloorToInt(g.Distance)+110,"Score combines distance and collectibles");
                float before=g.Distance;g.TogglePause();step(60,1,true);check(g.Distance==before && g.State==RunState.Paused,"Pause freezes simulation");g.TogglePause();
                g.Track.ClearTestItems();g.Track.PlaceTestItem(true,false,new Vector3(0,.6f,1));step(110,0,false);check(g.State==RunState.GameOver,"Rock collision ends run");
                check(PlayerPrefs.GetInt("EndlessRunner.Best",0)>=g.Score,"Best score persisted");
                var restart=UnityEngine.Object.FindObjectsByType<UnityEngine.UI.Button>(FindObjectsSortMode.None).First(b=>b.name=="RETRY");restart.onClick.Invoke();check(g.State==RunState.Running && g.Coins==0 && g.Gems==0 && g.Distance==0,"Restart button resets run");
                g.Track.ClearTestItems();step(5,0,false);step(12,0,true);g.Track.PlaceTestItem(true,false,new Vector3(0,.6f,1));step(7,0,false);check(g.State==RunState.Running,"Jump clears low rock");
                g.StartRun(0);g.Track.ClearTestItems();g.Track.Tick(75,.016f);check(g.Track.Recycled>0 && g.Track.ChunkCount==7,"Track recycles with bounded segment count");
                g.StartRun(0);g.Track.ClearTestItems();g.Track.PlaceTestCactus(new Vector3(0,0,1));step(110,0,false);check(g.State==RunState.GameOver,"Cactus collision ends run");
                g.StartRun(0);g.Track.ClearTestItems();g.Track.PlaceTestItem(true,false,new Vector3(0,.6f,5));g.Track.Tick(10,.05f);g.AdvanceDeath(2);check(g.State==RunState.GameOver,"Swept collision catches obstacle crossing player in one update");
                g.StartRun(0);for(int i=0;i<1000;i++){g.Track.ClearTestItems();g.Track.Tick(5,.016f);}check(g.Track.ChunkCount==7 && g.Track.Recycled>90 && g.Track.SpacingValid(),"5000-metre recycle stress check: bounded chunks and no gaps");
                for(int stage=0;stage<3;stage++){g.StartRun(stage);check(g.Stage==stage && g.State==RunState.Running,"Stage "+stage+" starts");}
                g.SetState(RunState.Instructions);check(g.State==RunState.Instructions,"Instructions navigation");
                g.ShowMenu();check(g.State==RunState.Menu,"Return to menu");
                check(UnityEngine.Object.FindObjectsByType<UnityEngine.EventSystems.EventSystem>(FindObjectsSortMode.None).Length==1,"Exactly one EventSystem");
                check(UnityEngine.Object.FindObjectsByType<AudioListener>(FindObjectsSortMode.None).Length==1,"Exactly one AudioListener");
            }
            catch(Exception ex){results.Add("FAIL Exception: "+ex);}
            finally{g.enabled=true;g.ShowMenu();PlayerPrefs.SetInt("EndlessRunner.Best",originalBest);PlayerPrefs.SetString(RunnerProgress.SaveKey,originalProgress);PlayerPrefs.Save();g.ReloadProgressForChecks();}
            Directory.CreateDirectory("TestResults");string report=string.Join("\n",results);File.WriteAllText("TestResults/gameplay-checks.txt",report);Debug.Log(report);return report;
        }
    }
}
#endif




