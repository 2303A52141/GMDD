using UnityEngine;

namespace EndlessRunner
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class RunnerAvatar : MonoBehaviour
    {
        public Transform leftLeg, rightLeg, leftArm, rightArm, body;
        [Min(1)] public float lateralSpeed=12, jumpSpeed=10, gravity=26;
        CharacterController controller; Animator animator;
        RunnerGame game;
        float velocityY, velocityX, cycle, step, slideTime;
        float standingHeight; Vector3 standingCenter;
        public bool Sliding => slideTime > 0;
        public float SlideRemaining => slideTime;
        public const float LaneSpacing = 3f;
        public int Lane { get; private set; } = 1;
        public float TargetX => (Lane - 1) * LaneSpacing;
        public float AnimationCycle => cycle;
        public bool Grounded => controller.isGrounded;
        public Bounds HitBounds => new Bounds(transform.position + Vector3.up * (Sliding ? .47f : 1.16f), new Vector3(.65f, Sliding ? .84f : 2.2f, .65f));
        public void Initialize(RunnerGame owner) { game = owner; animator=GetComponent<Animator>(); controller = GetComponent<CharacterController>(); ResetRunner(); }
        public void ResetRunner()
        {
            if(!controller) controller = GetComponent<CharacterController>();
            controller.enabled = false; transform.position = new Vector3(0, .05f, 0); controller.enabled = true;
            if(standingHeight == 0) { standingHeight=controller.height; standingCenter=controller.center; }
            slideTime=0; controller.height=standingHeight; controller.center=standingCenter;
            Lane = 1; velocityX = velocityY = cycle = step = 0;
            foreach(var limb in new[] {leftLeg, rightLeg, leftArm, rightArm}) limb.localRotation = Quaternion.identity;
            body.localRotation = Quaternion.identity;
        }
        public void RequestSlide()
        {
            if(!controller.isGrounded || Sliding) return;
            slideTime=.8f; controller.height=.9f; controller.center=Vector3.up*.48f; game.Audio.Play("slide");
        }
        public void Tick(float direction, bool jump, float dt)
        {
            bool wasGrounded=controller.isGrounded;
            if(Sliding) { slideTime=Mathf.Max(0,slideTime-dt); if(!Sliding) { controller.height=standingHeight; controller.center=standingCenter; } }
            // Direction is an input edge, never a held axis. New presses can retarget in midair.
            if(direction != 0) Lane = Mathf.Clamp(Lane + (direction > 0 ? 1 : -1), 0, 2);
            float nextX = Mathf.MoveTowards(transform.position.x, TargetX, lateralSpeed * dt);
            velocityX = dt > 0 ? (nextX - transform.position.x) / dt : 0;
            if(controller.isGrounded && velocityY < 0) velocityY = -2;
            if(jump && controller.isGrounded && !Sliding) { velocityY = jumpSpeed; game.Audio.Play("jump"); }
            velocityY -= gravity * dt;
            controller.Move(new Vector3(velocityX, velocityY, 0) * dt);
            if(!wasGrounded&&controller.isGrounded){game.Audio.Play("land");game.Track.Burst(transform.position,game.palette[0]);}

            cycle += dt * game.Speed * 1.15f;
            float swing = controller.isGrounded ? Mathf.Sin(cycle) * 38 : -22;
            if(!animator) { leftLeg.localRotation = Quaternion.Euler(swing, 0, 0); rightLeg.localRotation = Quaternion.Euler(-swing, 0, 0);
            leftArm.localRotation = Quaternion.Euler(-swing * .8f, 0, -10); rightArm.localRotation = Quaternion.Euler(swing * .8f, 0, 10);
            body.localRotation = Quaternion.Euler(7, 0, -velocityX * 1.4f); }
            step += dt;
            if(controller.isGrounded && !Sliding && step > 3.1f / game.Speed) { step = 0; game.Audio.Play("step"); }
        }
        public static GameObject Make(Material[] mats)
        {
            var root = new GameObject("DesertScout");
            var cc = root.AddComponent<CharacterController>(); cc.height = 1.9f; cc.radius = .32f; cc.center = new Vector3(0, .98f, 0); cc.stepOffset = .2f;
            var avatar = root.AddComponent<RunnerAvatar>();
            avatar.body = new GameObject("Animated Body").transform; avatar.body.SetParent(root.transform, false);
            Shape("Jacket", PrimitiveType.Capsule, avatar.body, new Vector3(0, 1.15f, 0), new Vector3(.65f, .43f, .42f), mats[6]);
            Shape("Head", PrimitiveType.Sphere, avatar.body, new Vector3(0, 1.88f, 0), Vector3.one * .43f, mats[7]);
            Shape("Turban", PrimitiveType.Sphere, avatar.body, new Vector3(0, 2.02f, 0), new Vector3(.53f, .32f, .49f), mats[8]);
            Shape("Scarf", PrimitiveType.Cube, avatar.body, new Vector3(0, 1.62f, .08f), new Vector3(.55f, .15f, .43f), mats[8]);
            Shape("Backpack", PrimitiveType.Cube, avatar.body, new Vector3(0, 1.2f, -.29f), new Vector3(.5f, .6f, .23f), mats[3]);
            avatar.leftLeg = Limb("Left Leg", avatar.body, new Vector3(-.20f, .85f, 0), new Vector3(.22f, .7f, .25f), mats[9]);
            avatar.rightLeg = Limb("Right Leg", avatar.body, new Vector3(.20f, .85f, 0), new Vector3(.22f, .7f, .25f), mats[9]);
            avatar.leftArm = Limb("Left Arm", avatar.body, new Vector3(-.43f, 1.48f, 0), new Vector3(.20f, .65f, .22f), mats[6]);
            avatar.rightArm = Limb("Right Arm", avatar.body, new Vector3(.43f, 1.48f, 0), new Vector3(.20f, .65f, .22f), mats[6]);
            return root;
        }
        static Transform Limb(string name, Transform parent, Vector3 pos, Vector3 scale, Material mat)
        {
            var pivot = new GameObject(name).transform; pivot.SetParent(parent, false); pivot.localPosition = pos;
            Shape("Limb", PrimitiveType.Cube, pivot, new Vector3(0, -scale.y / 2, 0), scale, mat); return pivot;
        }
        public static GameObject Shape(string name, PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Material mat)
        {
            var go = GameObject.CreatePrimitive(type); go.name = name; go.transform.SetParent(parent, false); go.transform.localPosition = pos; go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            var collider = go.GetComponent<Collider>(); if(Application.isPlaying) Destroy(collider); else DestroyImmediate(collider);
            return go;
        }
    }
}






