using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;

namespace EndlessRunner
{
    // Presentation only: all balances, rewards and timers come from the existing managers.
    public sealed class RunnerUI : MonoBehaviour
    {
        RunnerGame game; Transform canvas;
        readonly Dictionary<RunState,GameObject> screens=new Dictionary<RunState,GameObject>();
        readonly Dictionary<RunState,UnityEngine.UI.Button> firstButtons=new Dictionary<RunState,UnityEngine.UI.Button>();
        
        readonly List<UnityEngine.Object> generated=new List<UnityEngine.Object>();
        TMP_Text best,mute,score,gold,gems,distance,mode,runBest,toast;
        TMP_Text finalScore,finalDetail,finalBest,wallet,gemTotal,shopWallet;
        readonly TMP_Text[] milestoneText=new TMP_Text[4],missionText=new TMP_Text[3],upgradeText=new TMP_Text[3],rankText=new TMP_Text[10];
        readonly UnityEngine.UI.Image[] milestoneBars=new UnityEngine.UI.Image[4],missionBars=new UnityEngine.UI.Image[3],powerBars=new UnityEngine.UI.Image[4];
        readonly UnityEngine.UI.Button[] claims=new UnityEngine.UI.Button[3],purchases=new UnityEngine.UI.Button[3];
        readonly TMP_Text[] powerText=new TMP_Text[4];
        readonly GameObject[] powerCards=new GameObject[4];
        readonly float[] lastPower=new float[4];
        UnityEngine.UI.Button revive; TMP_Text emptyBoard; CanvasGroup hints,activeTransition; float transition,toastUntil;
        Sprite rounded,coinIcon,gemIcon; int previousCoins=-1,previousGems=-1,previousBank=-1; RunState current;
        static readonly Color Ink=new Color(.105f,.083f,.071f,.96f),Panel=new Color(.17f,.13f,.105f,.96f),Gold=new Color(.96f,.68f,.29f),Cream=new Color(.98f,.92f,.81f),Muted=new Color(.72f,.66f,.56f),Teal=new Color(.36f,.81f,.77f);
        static readonly string[] PowerNames={"MAGNET","SHIELD","SPEED BOOST","DOUBLE POINTS"};
        public void Initialize(RunnerGame owner)
        {
            game=owner;rounded=MakeSprite(0);coinIcon=MakeSprite(1);gemIcon=MakeSprite(2);
            var go=new GameObject("Game UI",typeof(Canvas),typeof(UnityEngine.UI.CanvasScaler),typeof(UnityEngine.UI.GraphicRaycaster));canvas=go.transform;go.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
            var scaler=go.GetComponent<UnityEngine.UI.CanvasScaler>();scaler.uiScaleMode=UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1600,900);scaler.screenMatchMode=UnityEngine.UI.CanvasScaler.ScreenMatchMode.Expand;
            if(!EventSystem.current)new GameObject("EventSystem",typeof(EventSystem),typeof(InputSystemUIInputModule));
            BuildMenu();BuildTrails();BuildInstructions();BuildCamp();BuildUpgrades();BuildBoard();BuildEndScreens();BuildHUD();
            var notice=Box(canvas,"Feedback",new Color(.12f,.09f,.06f,.97f));At(notice,520,52,0,-116,new Vector2(.5f,1));toast=Text(notice,"",21,Gold);Fill(toast.rectTransform,8);notice.gameObject.SetActive(false);
        }
        void BuildMenu()
        {
            var p=Screen(RunState.Menu,"AN ENDLESS DESERT ADVENTURE","ENDLESS\nRUNNER",false);
            var intro=Text(p,"Beyond the dunes. Beyond your best.",23,Muted);At(intro.rectTransform,480,48,0,-265,new Vector2(.5f,1));
            best=Text(p,"",19,Gold);At(best.rectTransform,480,40,0,-322,new Vector2(.5f,1));
            firstButtons[RunState.Menu]=ActionAt(p,"PLAY",()=>game.SetState(RunState.Stages),0,-397,480,true);
            ActionAt(p,"DESERT CAMP",()=>game.SetState(RunState.Progress),0,-469,480);
            ActionAt(p,"HOW TO PLAY",()=>game.SetState(RunState.Instructions),0,-541,480);
            var b=ActionAt(p,game.Audio.Muted?"SOUND: OFF":"SOUND: ON",()=>{game.Audio.ToggleMute();mute.text=game.Audio.Muted?"SOUND: OFF":"SOUND: ON";},-123,-613,234);mute=b.GetComponentInChildren<TMP_Text>();
            ActionAt(p,"QUIT",game.Quit,123,-613,234);
        }
        void BuildTrails()
        {
            var p=Screen(RunState.Stages,"ONE DESERT. THREE PACES.","CHOOSE YOUR TRAIL");
            string[] desc={"GOLDEN DUNES","RED CANYON","SUNFIRE PASS"};string[] detail={"Slow speed. More time to react.","Balanced speed and obstacles.","High speed. Quick reactions needed."};
            for(int i=0;i<3;i++){int id=i;var c=Card(p,"Trail "+i,-432+i*432,-166,408,402);var n=Text(c,"0"+(i+1),66,Gold);At(n.rectTransform,344,90,0,-30,new Vector2(.5f,1));var t=Text(c,desc[i],27,Cream,true);At(t.rectTransform,344,65,0,-136,new Vector2(.5f,1));var d=Text(c,detail[i]+"\n\n"+new[]{"EASY","NORMAL","FAST"}[i],21,Muted);At(d.rectTransform,344,118,0,-205,new Vector2(.5f,1));var b=ActionAt(c,"PLAY",()=>game.StartRun(id),0,-330,344,true);var colors=b.colors;colors.selectedColor=new Color(.88f,.90f,1f);b.colors=colors;if(i==0)firstButtons[RunState.Stages]=b;}
            Footer(p,"Every trail is endless. Speed increases as you travel.");ActionAt(p,"HOME",game.ShowMenu,0,-650,300);
        }
        void BuildInstructions()
        {
            var p=Screen(RunState.Instructions,"YOUR FIELD GUIDE","HOW TO PLAY");
            var left=Card(p,"Controls",-326,-170,620,412);var right=Card(p,"Field notes",326,-170,620,412);
            SmallHeading(left,"MOVE WITH CONFIDENCE",28);KeyRow(left,"A / D","CHANGE ONE LANE",88);KeyRow(left,"UP / W","JUMP  (ALSO SPACE)",164);KeyRow(left,"DOWN / S","SLIDE UNDER GATES",240);KeyRow(left,"ESC","PAUSE / RESUME",316);
            SmallHeading(right,"MAKE EVERY METRE COUNT",28);
            var notes=Text(right,"Collect gold and gems. Avoid cacti and trucks.\nJump rocks, logs, blocks and barriers.\nSlide under striped overhead gates.\n\nGold  +10 points    Gems  +100 points\nDistance  +1 point per metre\n\nMagnet attracts gold. Shield blocks one hit.\nBoost adds speed. x2 doubles new points.\nCoin bonus adds gold immediately.",22,Cream);At(notes.rectTransform,550,310,0,-88,new Vector2(.5f,1));notes.alignment=TextAlignmentOptions.TopLeft;
            Footer(p,"Left / Right change lanes. Up or Space jumps. Down slides. One revive per run.");firstButtons[RunState.Instructions]=ActionAt(p,"GOT IT",game.ShowMenu,0,-650,300,true);
        }
        void BuildCamp()
        {
            var p=Screen(RunState.Progress,"YOUR JOURNEY, SAVED HERE","DESERT CAMP");
            wallet=Currency(p,"WALLET GOLD",coinIcon,Gold,360,-36);gemTotal=Currency(p,"LIFETIME GEMS",gemIcon,Teal,550,-36);
            var left=Card(p,"Milestones",-326,-150,620,440);var right=Card(p,"Daily missions",326,-150,620,440);
            SmallHeading(left,"MILESTONES",24);SmallHeading(right,"DAILY MISSIONS",24);
            string[] titles={"FIRST FOOTPRINTS","GOLD SEEKER","GEM HUNTER","HORIZON CHASER"};
            for(int i=0;i<4;i++){var r=Box(left,"Milestone "+i,Ink);At(r,564,77,0,-78-i*86,new Vector2(.5f,1));milestoneText[i]=Text(r,titles[i],19,Cream);At(milestoneText[i].rectTransform,528,56,0,-6,new Vector2(.5f,1));milestoneText[i].alignment=TextAlignmentOptions.TopLeft;milestoneBars[i]=Bar(r,528,-66,Gold);}
            for(int i=0;i<3;i++){int id=i;var r=Box(right,"Mission "+i,Ink);At(r,564,106,0,-78-i*115,new Vector2(.5f,1));missionText[i]=Text(r,"",20,Cream);At(missionText[i].rectTransform,350,72,-86,-12,new Vector2(.5f,1));missionText[i].alignment=TextAlignmentOptions.TopLeft;claims[i]=ActionAt(r,"CLAIM +50",()=>{if(game.Progress.Claim(id)){RefreshData();Notify("DAILY REWARD  /  +50 GOLD");Pulse(wallet);}},196,-25,142,true,48);missionBars[i]=Bar(r,528,-92,Gold);}
            Footer(p,"Milestone rewards are granted automatically. Daily missions follow this computer's date.");
            ActionAt(p,"UPGRADES",()=>game.SetState(RunState.Upgrades),-352,-650,336,true);ActionAt(p,"LOCAL LEADERBOARD",()=>game.SetState(RunState.Leaderboard),0,-650,336);firstButtons[RunState.Progress]=ActionAt(p,"HOME",game.ShowMenu,352,-650,336);
        }
        void BuildUpgrades()
        {
            var p=Screen(RunState.Upgrades,"PREPARE FOR THE NEXT RUN","UPGRADES");shopWallet=Currency(p,"WALLET GOLD",coinIcon,Gold,550,-36);
            string[] names={"MAGNET","SHIELD","BOOST + DOUBLE POINTS"};string[] desc={"Pull nearby gold into your path.","Absorb one collision while protected.","Extend your speed and scoring powers."};
            for(int i=0;i<3;i++){int id=i;var c=Card(p,"Upgrade "+i,-432+i*432,-166,408,420);Icon(c,i==0?"M":i==1?"S":"x2",0,-30,Gold);var t=Text(c,names[i],25,Cream,true);At(t.rectTransform,360,64,0,-110,new Vector2(.5f,1));var d=Text(c,desc[i],21,Muted);At(d.rectTransform,344,64,0,-174,new Vector2(.5f,1));upgradeText[i]=Text(c,"",21,Cream);At(upgradeText[i].rectTransform,344,94,0,-243,new Vector2(.5f,1));purchases[i]=ActionAt(c,"UPGRADE",()=>{if(game.Progress.Buy(id)){RefreshData();Notify(names[id]+" UPGRADED");Pulse(shopWallet);}},0,-344,344,true);}
            Footer(p,"Earned gold only. Each level adds 2 seconds, up to level 3.");firstButtons[RunState.Upgrades]=ActionAt(p,"BACK TO CAMP",()=>game.SetState(RunState.Progress),0,-650,320);
        }
        void BuildBoard()
        {
            var p=Screen(RunState.Leaderboard,"PERSONAL RECORDS / THIS COMPUTER","LOCAL LEADERBOARD");
            var c=Card(p,"Saved scores",0,-148,1256,466);var h=Text(c,"<pos=30>RANK<pos=204>RUNNER<pos=580>POINTS<pos=920>DISTANCE",18,Muted);At(h.rectTransform,1184,36,0,-16,new Vector2(.5f,1));h.alignment=TextAlignmentOptions.Left;
            for(int i=0;i<10;i++){var r=Box(c,"Rank "+i,i==0?new Color(.30f,.22f,.12f,1):i%2==0?Panel:Ink);At(r,1192,36,0,-62-i*39,new Vector2(.5f,1));rankText[i]=Text(r,"",21,i==0?Gold:Cream);Fill(rankText[i].rectTransform,4);rankText[i].alignment=TextAlignmentOptions.Left;}
            emptyBoard=Text(c,"The desert is waiting.\nComplete a run to set your first record.",28,Cream);At(emptyBoard.rectTransform,1000,160,0,0,new Vector2(.5f,.5f));firstButtons[RunState.Leaderboard]=ActionAt(p,"BACK TO CAMP",()=>game.SetState(RunState.Progress),0,-650,320);
        }
        void BuildEndScreens()
        {
            var p=Screen(RunState.GameOver,"THE SANDS REMEMBER","GAME OVER",false,true);
            finalScore=Text(p,"",76,Gold,true);At(finalScore.rectTransform,480,100,0,-198,new Vector2(.5f,1));var pts=Text(p,"POINTS THIS RUN",16,Muted);At(pts.rectTransform,480,30,0,-300,new Vector2(.5f,1));finalDetail=Text(p,"",24,Cream);At(finalDetail.rectTransform,480,86,0,-342,new Vector2(.5f,1));finalBest=Text(p,"",20,Gold);At(finalBest.rectTransform,480,40,0,-432,new Vector2(.5f,1));firstButtons[RunState.GameOver]=ActionAt(p,"RETRY",()=>game.StartRun(game.Stage),0,-497,480,true);revive=ActionAt(p,"REVIVE / ONCE PER RUN",game.Revive,0,-569,480);ActionAt(p,"HOME",game.ShowMenu,0,-641,480);
            var pause=Screen(RunState.Paused,"TAKE A BREATHER","PAUSED",false,true);var msg=Text(pause,"Your journey will be waiting.\n\nESC to resume",24,Muted);At(msg.rectTransform,480,160,0,-245,new Vector2(.5f,1));firstButtons[RunState.Paused]=ActionAt(pause,"RESUME",game.TogglePause,0,-433,480,true);ActionAt(pause,"RESTART",()=>game.StartRun(game.Stage),0,-505,480);ActionAt(pause,"MAIN MENU",game.ShowMenu,0,-577,480);
        }
        void BuildHUD()
        {
            var root=Rect(canvas,"Gameplay HUD");Fill(root);screens[RunState.Running]=root.gameObject;
            var left=Box(root,"Score",Ink);At(left,282,104,28,-24,new Vector2(0,1));left.pivot=new Vector2(0,1);
            score=Text(left,"0",38,Cream,true);At(score.rectTransform,238,49,0,-11,new Vector2(.5f,1));score.alignment=TextAlignmentOptions.Left;runBest=Text(left,"",16,Muted);At(runBest.rectTransform,238,28,0,-65,new Vector2(.5f,1));runBest.alignment=TextAlignmentOptions.Left;
            var center=Box(root,"Trail",Ink);At(center,340,76,0,-24,new Vector2(.5f,1));mode=Text(center,"",18,Gold,true);At(mode.rectTransform,312,30,0,-7,new Vector2(.5f,1));distance=Text(center,"",19,Cream);At(distance.rectTransform,312,30,0,-37,new Vector2(.5f,1));
            var right=Box(root,"Run collectibles",Ink);At(right,350,76,-112,-24,new Vector2(1,1));right.pivot=new Vector2(1,1);gold=Currency(right,"RUN GOLD",coinIcon,Gold,-82,-5);gems=Currency(right,"RUN GEMS",gemIcon,Teal,82,-5);
            var pause=Button(root,"II",game.TogglePause,false);At(pause.GetComponent<RectTransform>(),64,76,-28,-24,new Vector2(1,1));pause.GetComponent<RectTransform>().pivot=new Vector2(1,1);
            var keys=Box(root,"Keyboard guidance",Ink);At(keys,716,52,0,22,new Vector2(.5f,0));keys.pivot=new Vector2(.5f,0);hints=keys.gameObject.AddComponent<CanvasGroup>();
            KeyHint(keys,"A / D","LANE",-261);KeyHint(keys,"UP","JUMP",-87);KeyHint(keys,"DOWN","SLIDE",87);KeyHint(keys,"ESC","PAUSE",261);
            for(int i=0;i<4;i++){var c=Box(root,PowerNames[i]+" status",Ink);At(c,244,90,28,100+i*102,new Vector2(0,0));c.pivot=new Vector2(0,0);powerCards[i]=c.gameObject;Icon(c,new[]{"M","S",">>","x2"}[i],-86,-18,i==1?Teal:Gold,44);powerText[i]=Text(c,"",17,Cream);At(powerText[i].rectTransform,158,50,29,-15,new Vector2(.5f,1));powerText[i].alignment=TextAlignmentOptions.Left;powerBars[i]=Bar(c,210,-76,i==1?Teal:Gold);}
        }
        RectTransform Screen(RunState state,string eyebrow,string title,bool wide=true,bool center=false)
        {
            var root=Rect(canvas,state+" Screen");Fill(root);screens[state]=root.gameObject;var shade=Box(root,"Backdrop",new Color(.065f,.045f,.025f,wide?.64f:.30f),false);Fill(shade);shade.GetComponent<UnityEngine.UI.Image>().raycastTarget=true;
            var surface=state==RunState.Menu?new Color(.105f,.083f,.071f,.78f):Ink;var p=Box(root,"Content",surface);At(p,wide?1320:568,760,0,0,new Vector2(wide||center?.5f:.22f,.5f));p.pivot=new Vector2(.5f,.5f);p.gameObject.AddComponent<CanvasGroup>();
            var accent=Box(p,"Amber rule",Gold,false);At(accent,wide?1256:480,3,0,-22,new Vector2(.5f,1));
            var e=Text(p,eyebrow,16,Gold);At(e.rectTransform,wide?1256:480,30,0,-36,new Vector2(.5f,1));e.alignment=wide?TextAlignmentOptions.Left:TextAlignmentOptions.Center;e.characterSpacing=3;
            var t=Text(p,title,state==RunState.Menu?82:48,Cream,true);At(t.rectTransform,wide?1256:480,state==RunState.Menu?190:92,0,-72,new Vector2(.5f,1));t.alignment=wide?TextAlignmentOptions.Left:TextAlignmentOptions.Center;t.characterSpacing=2;t.lineSpacing=-10;
            return p;
        }
        RectTransform Card(Transform p,string name,float x,float y,float w,float h){var c=Box(p,name,Panel);At(c,w,h,x,y,new Vector2(.5f,1));return c;}
        void SmallHeading(Transform p,string value,float y){var t=Text(p,value,20,Gold,true);At(t.rectTransform,564,34,0,-y,new Vector2(.5f,1));t.alignment=TextAlignmentOptions.Left;t.characterSpacing=2;}
        void Footer(Transform p,string value){var t=Text(p,value,18,Muted);At(t.rectTransform,1256,40,0,-602,new Vector2(.5f,1));}
        TMP_Text Currency(Transform parent,string caption,Sprite icon,Color tint,float x,float y){var r=Rect(parent,caption);At(r,190,70,x,y,new Vector2(.5f,1));var im=Box(r,"Icon",tint);im.GetComponent<UnityEngine.UI.Image>().sprite=icon;im.GetComponent<UnityEngine.UI.Image>().type=UnityEngine.UI.Image.Type.Simple;At(im,24,24,-76,-31,new Vector2(.5f,1));var label=Text(r,caption,12,Muted);At(label.rectTransform,146,22,18,-2,new Vector2(.5f,1));label.alignment=TextAlignmentOptions.Left;var val=Text(r,"0",25,tint,true);At(val.rectTransform,146,38,18,-24,new Vector2(.5f,1));val.alignment=TextAlignmentOptions.Left;return val;}
        void KeyHint(Transform p,string key,string label,float x){var k=Box(p,key,new Color(.29f,.23f,.18f,1));At(k,key.Length>3?73:58,32,x-40,-10,new Vector2(.5f,1));var t=Text(k,key,15,Cream,true);Fill(t.rectTransform);var l=Text(p,label,14,Muted);At(l.rectTransform,83,32,x+42,-10,new Vector2(.5f,1));}
        void KeyRow(Transform p,string key,string label,float y){var k=Box(p,key,Ink);At(k,140,58,-194,-y,new Vector2(.5f,1));var t=Text(k,key,22,Gold,true);Fill(t.rectTransform);var l=Text(p,label,21,Cream);At(l.rectTransform,370,58,82,-y,new Vector2(.5f,1));l.alignment=TextAlignmentOptions.Left;}
        void Icon(Transform p,string glyph,float x,float y,Color color,float size=64){var b=Box(p,"Power icon",new Color(color.r,color.g,color.b,.13f));At(b,size,size,x,y,new Vector2(.5f,1));var t=Text(b,glyph,(int)(size*.42f),color,true);Fill(t.rectTransform);}
        UnityEngine.UI.Image Bar(Transform p,float width,float y,Color color){var bg=Box(p,"Progress track",new Color(.32f,.27f,.21f,1));At(bg,width,4,0,y,new Vector2(.5f,1));var f=Box(bg,"Progress fill",color);Fill(f);var im=f.GetComponent<UnityEngine.UI.Image>();f.gameObject.AddComponent<RunnerUIBar>();return im;}
        static void SetBar(UnityEngine.UI.Image im,float value){im.GetComponent<RunnerUIBar>().Target=Mathf.Clamp01(value);}
        TMP_Text Text(Transform p,string value,int size,Color color,bool bold=false){var r=Rect(p,value.Length<30?value:"Text");var t=r.gameObject.AddComponent<TextMeshProUGUI>();t.font=(size>=34&&game.displayFont)?game.displayFont:game.font;t.text=value;t.fontSize=size;t.color=color;t.alignment=TextAlignmentOptions.Center;t.raycastTarget=false;t.enableAutoSizing=false;t.fontStyle=bold?FontStyles.Bold:FontStyles.Normal;t.textWrappingMode=TextWrappingModes.Normal;return t;}
        UnityEngine.UI.Button ActionAt(Transform p,string label,Action action,float x,float y,float width,bool primary=false,float height=58){var b=Button(p,label,action,primary);At(b.GetComponent<RectTransform>(),width,height,x,y,new Vector2(.5f,1));return b;}
        UnityEngine.UI.Button Button(Transform p,string label,Action action,bool primary){var r=Box(p,label,primary?Gold:new Color(.26f,.21f,.17f,1));var im=r.GetComponent<UnityEngine.UI.Image>();im.raycastTarget=true;var b=r.gameObject.AddComponent<UnityEngine.UI.Button>();b.targetGraphic=im;var c=b.colors;c.normalColor=Color.white;c.highlightedColor=new Color(1.18f,1.12f,1.03f);c.selectedColor=c.highlightedColor;c.pressedColor=new Color(.75f,.72f,.66f);c.disabledColor=new Color(.46f,.43f,.38f,.75f);c.fadeDuration=.08f;b.colors=c;var t=Text(r,label,label.Length>19?18:21,primary?Ink:Cream,true);Fill(t.rectTransform,8);b.onClick.AddListener(()=>{game.Audio.Play("click");action();});return b;}
        RectTransform Rect(Transform p,string name){var go=new GameObject(name,typeof(RectTransform));go.transform.SetParent(p,false);return go.GetComponent<RectTransform>();}
        RectTransform Box(Transform p,string name,Color color,bool round=true){var r=Rect(p,name);var im=r.gameObject.AddComponent<UnityEngine.UI.Image>();im.color=color;im.raycastTarget=false;if(round){im.sprite=rounded;im.type=UnityEngine.UI.Image.Type.Sliced;}return r;}
        static void At(RectTransform r,float w,float h,float x,float y,Vector2 anchor){r.anchorMin=r.anchorMax=anchor;r.pivot=new Vector2(.5f,1);r.sizeDelta=new Vector2(w,h);r.anchoredPosition=new Vector2(x,y);}
        static void Fill(RectTransform r,float pad=0){r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=new Vector2(pad,pad);r.offsetMax=new Vector2(-pad,-pad);}
        Sprite MakeSprite(int kind){int s=64;var texture=new Texture2D(s,s,TextureFormat.RGBA32,false);texture.name="Desert UI "+kind;var pixels=new Color[s*s];for(int y=0;y<s;y++)for(int x=0;x<s;x++){float dx=Mathf.Abs(x-31.5f),dy=Mathf.Abs(y-31.5f);float edge=kind==1?28-Mathf.Sqrt(dx*dx+dy*dy):kind==2?29-(dx+dy):10-Mathf.Sqrt(Mathf.Pow(Mathf.Max(0,dx-21),2)+Mathf.Pow(Mathf.Max(0,dy-21),2));pixels[y*s+x]=new Color(1,1,1,Mathf.Clamp01(edge));}texture.SetPixels(pixels);texture.Apply();var sprite=Sprite.Create(texture,new Rect(0,0,s,s),new Vector2(.5f,.5f),100,0,SpriteMeshType.FullRect,new Vector4(14,14,14,14));generated.Add(sprite);generated.Add(texture);return sprite;}
        public void Show(RunState state)
        {
            if(state==RunState.Dying)state=RunState.Running;
            current=state;if(toast)toast.transform.parent.gameObject.SetActive(false);foreach(var s in screens)s.Value.SetActive(s.Key==state);RefreshData();UpdateHUD();
            activeTransition=screens[state].GetComponentInChildren<CanvasGroup>();transition=0;if(activeTransition)activeTransition.alpha=.65f;
            if(EventSystem.current)EventSystem.current.SetSelectedGameObject(state!=RunState.Stages&&firstButtons.TryGetValue(state,out var b)?b.gameObject:null);
        }
        void RefreshData()
        {
            var d=game.Progress.Data;best.text="PERSONAL BEST   "+game.Best.ToString("N0")+" PTS";wallet.text=d.bank.ToString("N0");gemTotal.text=d.gems.ToString("N0");shopWallet.text=wallet.text;if(previousBank>=0&&previousBank!=d.bank){Pulse(wallet);Pulse(shopWallet);}previousBank=d.bank;
            finalScore.text=game.Score.ToString("N0");finalDetail.text=$"{game.Distance:N0} METRES\n{game.Coins:N0} GOLD     /     {game.Gems:N0} GEMS";finalBest.text=$"PERSONAL BEST   {game.Best:N0}";revive.interactable=game.CanRevive;
            string[] titles={"FIRST FOOTPRINTS","GOLD SEEKER","GEM HUNTER","HORIZON CHASER"};float[] vals={d.runs,d.coins,d.gems,d.longest};float[] targets={1,100,10,1000};
            for(int i=0;i<4;i++){bool done=(d.achievements&(1<<i))!=0;milestoneText[i].text=titles[i]+"\n<size=16>"+(done?"COMPLETE  /  +25 GOLD AWARDED":$"{Mathf.Min(vals[i],targets[i]):N0} / {targets[i]:N0}  /  REWARD +25 GOLD")+"</size>";milestoneText[i].color=done?Gold:Cream;SetBar(milestoneBars[i],vals[i]/targets[i]);}
            string[] missionNames={"COLLECT 30 GOLD","FIND 5 GEMS","TRAVEL 500 METRES"};float[] mv={d.dailyCoins,d.dailyGems,d.dailyDistance},mt={30,5,500};
            for(int i=0;i<3;i++){bool claimed=(d.claimed&(1<<i))!=0,ready=game.Progress.MissionReady(i);missionText[i].text=missionNames[i]+$"\n<size=17>{Mathf.Min(mv[i],mt[i]):N0} / {mt[i]:N0}  /  "+(claimed?"REWARD CLAIMED":ready?"REWARD READY":"IN PROGRESS")+"</size>";SetBar(missionBars[i],mv[i]/mt[i]);claims[i].interactable=ready&&!claimed;claims[i].GetComponentInChildren<TMP_Text>().text=claimed?"CLAIMED":ready?"CLAIM +50":"+50 GOLD";int level=game.Progress.Level(i),cost=game.Progress.Cost(i);purchases[i].interactable=level<3&&d.bank>=cost;upgradeText[i].text=$"LEVEL {level} / 3\n"+(level==3?$"MAXIMUM / {game.powerDuration+6:0}s":$"{game.powerDuration+level*2:0}s  >  {game.powerDuration+(level+1)*2:0}s NEXT");purchases[i].GetComponentInChildren<TMP_Text>().text=level==3?"MAX LEVEL":d.bank<cost?$"NEED {cost} GOLD":$"UPGRADE / {cost} GOLD";}
            emptyBoard.gameObject.SetActive(d.scores.Count==0);for(int i=0;i<10;i++){rankText[i].transform.parent.gameObject.SetActive(i<d.scores.Count);if(i<d.scores.Count){var s=d.scores[i];rankText[i].text=$"<pos=30>{i+1:00}<pos=204>YOU{(i==0?" / BEST":"")}<pos=580>{s.score:N0}<pos=920>{s.distance:N0} m";}}
        }
        public void UpdateHUD()
        {
            score.text=game.Score.ToString("N0")+" <size=15>PTS</size>";runBest.text="BEST   "+game.Best.ToString("N0");gold.text=game.Coins.ToString("N0");gems.text=game.Gems.ToString("N0");distance.text=game.Distance.ToString("N0")+" METRES";mode.text=game.Difficulty.Name+" / "+RunnerGame.StageNames[game.Stage];
            if(previousCoins>=0&&game.Coins>previousCoins)Pulse(gold);if(previousGems>=0&&game.Gems>previousGems)Pulse(gems);previousCoins=game.Coins;previousGems=game.Gems;
            for(int i=0;i<4;i++){float left=game.Powers.Remaining((PowerKind)i);powerCards[i].SetActive(left>0);if(current==RunState.Running){if(left>lastPower[i]+.2f)Notify(PowerNames[i]+" ACTIVE");else if(left==0&&lastPower[i]>0)Notify(PowerNames[i]+" ENDED");}lastPower[i]=left;powerText[i].text=PowerNames[i]+$"\n{left:0.0}s";int level=i==0?game.Progress.Data.magnetLevel:i==1?game.Progress.Data.shieldLevel:game.Progress.Data.durationLevel;SetBar(powerBars[i],left/(game.powerDuration+level*2));}
        }
        void Notify(string value){toast.text=value;toast.transform.parent.gameObject.SetActive(true);toastUntil=Time.unscaledTime+2;}
        void Pulse(TMP_Text t){var p=t.GetComponent<RunnerUIPulse>();if(!p)p=t.gameObject.AddComponent<RunnerUIPulse>();p.Play();}
        void Update(){var keyboard=UnityEngine.InputSystem.Keyboard.current;if(current==RunState.Stages&&EventSystem.current&&!EventSystem.current.currentSelectedGameObject&&keyboard!=null&&(keyboard.tabKey.wasPressedThisFrame||keyboard.leftArrowKey.wasPressedThisFrame||keyboard.rightArrowKey.wasPressedThisFrame||keyboard.upArrowKey.wasPressedThisFrame||keyboard.downArrowKey.wasPressedThisFrame))EventSystem.current.SetSelectedGameObject(firstButtons[RunState.Stages].gameObject);if(activeTransition){transition+=Time.unscaledDeltaTime;activeTransition.alpha=Mathf.Lerp(.65f,1,transition/.16f);if(transition>=.16f)activeTransition=null;}if(toast&&Time.unscaledTime>toastUntil)toast.transform.parent.gameObject.SetActive(false);if(hints)hints.alpha=game.Distance>150?.45f:1;}
        void OnDestroy(){foreach(var obj in generated)if(obj)Destroy(obj);if(canvas)Destroy(canvas.gameObject);}
    }
    public sealed class RunnerUIBar : MonoBehaviour
    {
        public float Target;float shown;RectTransform rect;
        void Awake(){rect=GetComponent<RectTransform>();}
        void OnEnable(){shown=0;if(!rect)rect=GetComponent<RectTransform>();rect.anchorMax=new Vector2(0,1);rect.offsetMax=Vector2.zero;}
        void Update(){shown=Mathf.MoveTowards(shown,Target,Time.unscaledDeltaTime*2.5f);rect.anchorMax=new Vector2(shown,1);rect.offsetMax=Vector2.zero;}
    }
    public sealed class RunnerUIPulse : MonoBehaviour
    {
        float until;public void Play(){until=Time.unscaledTime+.18f;enabled=true;}
        void Update(){float t=Mathf.Clamp01((until-Time.unscaledTime)/.18f);transform.localScale=Vector3.one*(1+.07f*Mathf.Sin(t*Mathf.PI));if(t==0)enabled=false;}
        void OnDisable(){transform.localScale=Vector3.one;}
    }
}












