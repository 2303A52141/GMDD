using UnityEngine;
namespace EndlessRunner
{
    // Articulated original mesh character; no root motion or competing physics controller.
    public sealed class ExplorerVisual : MonoBehaviour
    {
        public Transform leftKnee,rightKnee,leftElbow,rightElbow,head,scarf;
        Animator animator; string activeClip; RunnerAvatar avatar;RunnerGame game;float cycle,land;bool grounded;
        public string AnimationState {get;private set;}
        bool knockedOut; Vector3 impactPosition; Quaternion impactRotation,impactHead;
        readonly Transform[] stars=new Transform[4];
        void KnockoutPose()
        {
            if(!knockedOut){knockedOut=true;impactPosition=avatar.body.localPosition;impactRotation=avatar.body.localRotation;impactHead=head.localRotation;if(animator)animator.enabled=false;}
            AnimationState="Knockout";
            float time=game.DeathElapsed;
            if(time<.12f)return; // Hold the exact impact pose before the forward tumble.
            float fall=Mathf.SmoothStep(0,1,Mathf.Clamp01((time-.12f)/.68f));
            avatar.body.localPosition=Vector3.Lerp(impactPosition,new Vector3(0,.30f,1.55f),fall)+Vector3.up*(Mathf.Sin(fall*Mathf.PI)*.32f);
            avatar.body.localRotation=Quaternion.Slerp(impactRotation,Quaternion.Euler(82,0,-16),fall);
            avatar.leftArm.localRotation=Quaternion.Euler(-120*fall,0,-25*fall);avatar.rightArm.localRotation=Quaternion.Euler(-105*fall,0,30*fall);
            avatar.leftLeg.localRotation=Quaternion.Euler(-20*fall,0,-10*fall);avatar.rightLeg.localRotation=Quaternion.Euler(25*fall,0,12*fall);
            leftKnee.localRotation=Quaternion.Euler(55*fall,0,0);rightKnee.localRotation=Quaternion.Euler(35*fall,0,0);
            leftElbow.localRotation=rightElbow.localRotation=Quaternion.Euler(-30*fall,0,0);
            head.localRotation=impactHead*Quaternion.Euler(0,Mathf.Sin(time*22)*18*fall,Mathf.Sin(time*17)*25*fall);
            for(int i=0;i<stars.Length;i++){
                if(!stars[i]){var star=GameObject.CreatePrimitive(PrimitiveType.Sphere);star.name="Knockout star "+i;Destroy(star.GetComponent<Collider>());star.transform.SetParent(transform,false);star.transform.localScale=new Vector3(.12f,.06f,.12f);star.GetComponent<Renderer>().sharedMaterial=game.palette[4];stars[i]=star.transform;}
                stars[i].gameObject.SetActive(time>.55f);float a=Time.unscaledTime*5+i*Mathf.PI*.5f;stars[i].position=head.position+new Vector3(Mathf.Cos(a)*.48f,.42f+Mathf.Sin(a*2)*.07f,Mathf.Sin(a)*.48f);
            }
        }
        void ClearKnockout()
        {
            if(!knockedOut)return;knockedOut=false;avatar.body.localPosition=Vector3.zero;avatar.body.localRotation=Quaternion.identity;head.localRotation=Quaternion.identity;
            foreach(var star in stars)if(star)star.gameObject.SetActive(false);
            activeClip=null;if(animator){animator.enabled=true;animator.speed=1;animator.Play("Idle",0,0);}
        }
        void Awake(){animator=GetComponent<Animator>();avatar=GetComponent<RunnerAvatar>();game=FindFirstObjectByType<RunnerGame>();}
        void LateUpdate()
        {
            if(!avatar||!game)return;
            if(game.State==RunState.Dying||(game.State==RunState.GameOver&&game.DeathElapsed>0)){KnockoutPose();return;}
            ClearKnockout();
            bool running=game.State==RunState.Running;
            if(animator && animator.runtimeAnimatorController)
            {
                animator.speed=game.State==RunState.Paused?0:1;
                if(game.State==RunState.Paused)return;
                if(!grounded&&avatar.Grounded)land=.16f;
                grounded=avatar.Grounded;land=Mathf.Max(0,land-Time.deltaTime);
                AnimationState=game.State==RunState.GameOver?"Hit":!running?"Idle":avatar.Sliding?"Slide":!grounded?"Jump":land>0?"Landing":"Run";
                animator.SetFloat("RunSpeed",game.Speed/11f);
                if(activeClip!=AnimationState){animator.CrossFadeInFixedTime(AnimationState,AnimationState=="Slide"?.045f:.09f);activeClip=AnimationState;}
                return;
            }
            if(game.State==RunState.Paused)return;
            if(game.State==RunState.GameOver){AnimationState="Hit";return;}
            if(!running){AnimationState="Idle";leftKnee.localRotation=rightKnee.localRotation=Quaternion.identity;leftElbow.localRotation=rightElbow.localRotation=Quaternion.Euler(-15,0,0);avatar.body.localRotation=Quaternion.Euler(0,155,0);avatar.body.localPosition=Vector3.up*(Mathf.Sin(Time.time*2)*.008f);head.localRotation=Quaternion.Euler(0,Mathf.Sin(Time.time*.7f)*4,0);return;}
            if(avatar.Sliding){AnimationState="Slide";avatar.body.localPosition=new Vector3(0,-.65f,0);avatar.body.localRotation=Quaternion.Euler(45,0,0);avatar.leftLeg.localRotation=Quaternion.Euler(-60,0,-8);avatar.rightLeg.localRotation=Quaternion.Euler(-55,0,8);leftKnee.localRotation=rightKnee.localRotation=Quaternion.Euler(95,0,0);leftElbow.localRotation=rightElbow.localRotation=Quaternion.Euler(-75,0,0);head.localRotation=Quaternion.Euler(-35,0,0);return;}
            if(!grounded&&avatar.Grounded)land=.16f;grounded=avatar.Grounded;land=Mathf.Max(0,land-Time.deltaTime);
            cycle=avatar.AnimationCycle;AnimationState=!grounded?"Jump":land>0?"Landing":"Run";
            float l=grounded?Mathf.Max(0,-Mathf.Sin(cycle))*65:65,r=grounded?Mathf.Max(0,Mathf.Sin(cycle))*65:28;
            leftKnee.localRotation=Quaternion.Euler(l,0,0);rightKnee.localRotation=Quaternion.Euler(r,0,0);
            leftElbow.localRotation=Quaternion.Euler(-35-Mathf.Sin(cycle)*12,0,0);rightElbow.localRotation=Quaternion.Euler(-35+Mathf.Sin(cycle)*12,0,0);
            avatar.body.localPosition=Vector3.up*((grounded?Mathf.Abs(Mathf.Sin(cycle))*.025f:0)-land*.18f);head.localRotation=Quaternion.Euler(-4,0,0);
            scarf.localRotation=Quaternion.Euler(Mathf.Sin(cycle*.6f)*12,Mathf.Sin(cycle*.35f)*9,0);
        }
    }
}




