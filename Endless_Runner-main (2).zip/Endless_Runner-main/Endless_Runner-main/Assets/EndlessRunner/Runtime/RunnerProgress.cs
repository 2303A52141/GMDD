using System;
using System.Collections.Generic;
using UnityEngine;

namespace EndlessRunner
{
    [Serializable] public sealed class LocalScore { public string id, date; public int score; public float distance; }
    [Serializable] public sealed class ProgressData
    {
        public int bank, coins, gems, runs, achievements, claimed, magnetLevel, shieldLevel, durationLevel;
        public int dailyCoins, dailyGems, dailyScore;
        public float dailyDistance, longest;
        public string day="";
        public List<LocalScore> scores=new List<LocalScore>();
    }
    public sealed class RunnerProgress
    {
        public const string SaveKey="EndlessRunner.Progress.v2";
        public ProgressData Data {get;private set;}
        float nextDayCheck;
        public RunnerProgress()
        {
            try {Data=JsonUtility.FromJson<ProgressData>(PlayerPrefs.GetString(SaveKey,""));}catch{Data=null;}
            if(Data==null)Data=new ProgressData();
            if(Data.scores==null)Data.scores=new List<LocalScore>();
            Data.bank=Mathf.Max(0,Data.bank);Data.magnetLevel=Mathf.Clamp(Data.magnetLevel,0,3);Data.shieldLevel=Mathf.Clamp(Data.shieldLevel,0,3);Data.durationLevel=Mathf.Clamp(Data.durationLevel,0,3);
            CheckDay(DateTime.Now.ToString("yyyy-MM-dd"));
        }
        public void CheckDay(string day)
        {
            // A backwards system clock does not grant another set of daily rewards.
            if(string.IsNullOrEmpty(Data.day)||string.CompareOrdinal(day,Data.day)>0){Data.day=day;Data.dailyCoins=Data.dailyGems=Data.dailyScore=Data.claimed=0;Data.dailyDistance=0;Save();}
        }
        public void Collect(int coins,int gems)
        {
            CheckDay(DateTime.Now.ToString("yyyy-MM-dd"));Data.bank+=coins;Data.coins+=coins;Data.gems+=gems;Data.dailyCoins+=coins;Data.dailyGems+=gems;Achievements();
        }
        public void Travel(float metres,int score){if(Time.unscaledTime>=nextDayCheck){nextDayCheck=Time.unscaledTime+1;CheckDay(DateTime.Now.ToString("yyyy-MM-dd"));}Data.dailyDistance+=Mathf.Max(0,metres);Data.dailyScore=Mathf.Max(Data.dailyScore,score);}
        public void Record(string id,int score,float distance,bool first)
        {
            if(first)Data.runs++;Data.longest=Mathf.Max(Data.longest,distance);
            Data.scores.RemoveAll(s=>s.id==id);Data.scores.Add(new LocalScore{id=id,date=DateTime.Now.ToString("yyyy-MM-dd"),score=Mathf.Max(0,score),distance=distance});
            Data.scores.Sort((a,b)=>b.score.CompareTo(a.score));if(Data.scores.Count>10)Data.scores.RemoveRange(10,Data.scores.Count-10);
            Achievements();Save();
        }
        void Achievements()
        {
            bool[] unlocked={Data.runs>=1,Data.coins>=100,Data.gems>=10,Data.longest>=1000};
            for(int i=0;i<4;i++)if(unlocked[i]&&(Data.achievements&(1<<i))==0){Data.achievements|=1<<i;Data.bank+=25;}
        }
        public bool MissionReady(int i)=>i==0?Data.dailyCoins>=30:i==1?Data.dailyGems>=5:Data.dailyDistance>=500;
        public bool Claim(int i)
        {
            CheckDay(DateTime.Now.ToString("yyyy-MM-dd"));if(i<0||i>2||!MissionReady(i)||(Data.claimed&(1<<i))!=0)return false;
            Data.claimed|=1<<i;Data.bank+=50;Save();return true;
        }
        public int Level(int i)=>i==0?Data.magnetLevel:i==1?Data.shieldLevel:Data.durationLevel;
        public int Cost(int i)=>50*(Level(i)+1);
        public bool Buy(int i)
        {
            if(i<0||i>2||Level(i)>=3||Data.bank<Cost(i))return false;
            Data.bank-=Cost(i);if(i==0)Data.magnetLevel++;else if(i==1)Data.shieldLevel++;else Data.durationLevel++;Save();return true;
        }
        public void Save(){PlayerPrefs.SetString(SaveKey,JsonUtility.ToJson(Data));PlayerPrefs.Save();}
    }
}
