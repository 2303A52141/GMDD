using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

namespace EndlessRunner
{
    public enum RunState { Menu, Stages, Instructions, Running, Paused, GameOver, Progress, Upgrades, Leaderboard, Dying }
    public sealed class RunnerGame : MonoBehaviour
    {
        public Material[] palette;
        public TMP_FontAsset font;
        public TMP_FontAsset displayFont;
        public GameObject runnerPrefab;
        public GameObject[] obstaclePrefabs;
        public UnityEngine.Rendering.VolumeProfile lookProfile;
        [Header("Gameplay tuning")]
        [Min(1)] public float powerDuration=8;
        [Min(1)] public float magnetRadius=9;
        [Min(1)] public int coinBonus=25;
        [Range(1,1.5f)] public float boostFactor=1.25f;
        [Range(0,1)] public float effectsVolume=.45f;
        public AudioClip backgroundMusic;
        public Material desertSky;
        public RunState State { get; private set; }
        public float Distance { get; private set; }
        public int Coins { get; private set; }
        public int Gems { get; private set; }
        public int Score => Mathf.FloorToInt(scoreValue);
        float scoreValue, reviveGrace;
        public float DeathElapsed {get;private set;}
        public const float DeathDuration=1.65f;
        bool revived, recorded;
        string runId;
        public bool CanRevive=>State==RunState.GameOver&&!revived;
        public RunnerPowers Powers {get;private set;}
        public RunnerProgress Progress {get;private set;}
        public int Best { get; private set; }
        public int Stage { get; private set; }
        public RunnerDifficulty Difficulty => RunnerDifficulty.For(Stage);
        public float Speed => Difficulty.SpeedAt(Distance)*(Powers!=null&&Powers.Boost?boostFactor:1);
        public RunnerAvatar Player { get; private set; }
        public DesertTrack Track { get; private set; }
        public RunnerUI UI { get; private set; }
        public RunnerAudio Audio { get; private set; }
        Camera view;
        float steer, hudTime;
        bool jump;
        public static readonly string[] StageNames = { "GOLDEN DUNES", "RED CANYON", "SUNFIRE PASS" };

        void Awake()
        {
            Application.targetFrameRate = 60;
            Time.timeScale=1;
            Progress=new RunnerProgress();Powers=new RunnerPowers(this);
            Best = PlayerPrefs.GetInt("EndlessRunner.Best", 0);
            Audio = gameObject.AddComponent<RunnerAudio>();
            Player = Instantiate(runnerPrefab).GetComponent<RunnerAvatar>();
            Player.name = "Desert Scout";
            Player.Initialize(this);
            view = new GameObject("Follow Camera", typeof(Camera), typeof(AudioListener)).GetComponent<Camera>();
            view.tag = "MainCamera";
            view.fieldOfView = 58; view.farClipPlane = 420;
            view.clearFlags = CameraClearFlags.SolidColor;
            var cameraData=view.gameObject.AddComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>();cameraData.renderPostProcessing=true;
            cameraData.antialiasing=UnityEngine.Rendering.Universal.AntialiasingMode.SubpixelMorphologicalAntiAliasing;
            if(lookProfile){var volume=new GameObject("Desert atmosphere").AddComponent<UnityEngine.Rendering.Volume>();volume.isGlobal=true;volume.sharedProfile=lookProfile;}
            view.transform.position = new Vector3(0, 4.5f, -7.8f);
            view.transform.rotation = Quaternion.Euler(18, 0, 0);
            var sun = new GameObject("Desert Sun").AddComponent<Light>();
            sun.type = LightType.Directional; sun.intensity = 1.35f;
            sun.color = new Color(1, .86f, .65f); sun.shadows = LightShadows.Soft;
            sun.transform.rotation = Quaternion.Euler(38, -35, 0);
            RenderSettings.ambientLight = new Color(.58f, .55f, .48f);
            RenderSettings.fog = true; RenderSettings.fogMode = FogMode.ExponentialSquared; RenderSettings.fogDensity = .0065f;
            Track = new GameObject("Recycled Desert").AddComponent<DesertTrack>(); Track.Initialize(this);
            UI = gameObject.AddComponent<RunnerUI>(); UI.Initialize(this);
            ShowMenu();
            Debug.Log("ENDLESS_RUNNER_READY: gameplay, UI, track and save systems initialized.");
            if(System.Array.IndexOf(System.Environment.GetCommandLineArgs(),"--runner-self-test")>=0)gameObject.AddComponent<RunnerBuildProbe>();
        }
        public void SetState(RunState state) { State = state; Time.timeScale=state==RunState.Paused?0:1; UI.Show(state==RunState.Dying?RunState.Running:state); }
        public void ShowMenu()
        {
            State = RunState.Menu; Stage = 0; Distance = 0; Coins = 0; Gems = 0;
            scoreValue=0;DeathElapsed=0;Time.timeScale=1;Powers.Reset();Progress.Save();
            Best = PlayerPrefs.GetInt("EndlessRunner.Best", 0);
            Player.ResetRunner(); Track.ResetTrack(0,7301); ApplySky(); UI.Show(State);
        }
        public void StartRun(int stage)
        {
            Stage = Mathf.Clamp(stage, 0, 2); Distance = 0; Coins = 0; Gems = 0;
            scoreValue=0;DeathElapsed=0;revived=recorded=false;reviveGrace=0;runId=System.Guid.NewGuid().ToString("N");Powers.Reset();Progress.CheckDay(System.DateTime.Now.ToString("yyyy-MM-dd"));
            Player.ResetRunner(); Track.ResetTrack(Stage); ApplySky(); SetState(RunState.Running);
            Audio.Play("start");
        }
        void ApplySky()
        {
            var sky = new Color(.74f, .83f, .85f);
            view.backgroundColor = sky; RenderSettings.fogColor = new Color(.80f,.69f,.54f);
            RenderSettings.skybox=desertSky;view.clearFlags=desertSky?CameraClearFlags.Skybox:CameraClearFlags.SolidColor;
        }
        public void Collect(bool gem, Vector3 position)
        {
            if (State != RunState.Running) return;
            if (gem) Gems++; else Coins++;
            scoreValue+=(gem?100:10)*Powers.Multiplier;Progress.Collect(gem?0:1,gem?1:0);
            Audio.Play(gem ? "gem" : "coin"); Track.Burst(position, gem ? palette[5] : palette[4]); UI.UpdateHUD();
        }
        public void EndRun()
        {
            if (State != RunState.Running) return;
            Audio.Play("crash");
            DeathElapsed=0;Track.Burst(Player.transform.position+Vector3.up,palette[0]);
            if (Score > Best) { Best = Score; PlayerPrefs.SetInt("EndlessRunner.Best", Best); PlayerPrefs.Save(); }
            Powers.Reset();Progress.Record(runId,Score,Distance,!recorded);recorded=true;
            SetState(RunState.Dying);
        }
        public void AdvanceDeath(float dt)
        {
            if(State!=RunState.Dying)return;
            DeathElapsed=Mathf.Min(DeathDuration,DeathElapsed+Mathf.Max(0,dt));
            // Stop world travel and scoring; animate the fall on an independent unscaled clock.
            Track.Tick(0,dt);
            if(DeathElapsed>=DeathDuration)SetState(RunState.GameOver);
        }
        public void AwardCoins(int amount)
        {
            if(State!=RunState.Running||amount<=0)return;Coins+=amount;scoreValue+=amount*10*Powers.Multiplier;Progress.Collect(amount,0);UI.UpdateHUD();
        }
        public void HitObstacle()
        {
            if(State!=RunState.Running)return;
            if(reviveGrace>0||Powers.Absorb()){Track.Burst(Player.transform.position+Vector3.up,palette[5]);return;}EndRun();
        }
        public void Revive()
        {
            if(!CanRevive)return;DeathElapsed=0;revived=true;reviveGrace=3;Powers.Reset();Player.ResetRunner();Track.ClearNearPlayer(20);SetState(RunState.Running);Audio.Play("power");
        }
        public void TogglePause()
        {
            if(State == RunState.Running) SetState(RunState.Paused);
            else if(State == RunState.Paused) SetState(RunState.Running);
        }
        void Update()
        {
            if(State==RunState.Dying){AdvanceDeath(Time.unscaledDeltaTime);return;}
            var keyboard = Keyboard.current;
            if (keyboard != null && keyboard.escapeKey.wasPressedThisFrame) TogglePause();
            if (State != RunState.Running) return;
            steer = keyboard == null ? 0 : ((keyboard.dKey.wasPressedThisFrame || keyboard.rightArrowKey.wasPressedThisFrame ? 1 : 0) - (keyboard.aKey.wasPressedThisFrame || keyboard.leftArrowKey.wasPressedThisFrame ? 1 : 0));
            jump = keyboard != null && (keyboard.spaceKey.wasPressedThisFrame || keyboard.upArrowKey.wasPressedThisFrame || keyboard.wKey.wasPressedThisFrame);
            if(keyboard != null && (keyboard.downArrowKey.wasPressedThisFrame || keyboard.sKey.wasPressedThisFrame)) Player.RequestSlide();
#if UNITY_EDITOR
            if (TestControls) { steer = TestSteer; jump = TestJump; TestSteer = 0; TestJump = false; }
#endif
            Advance(steer, jump, Mathf.Min(Time.deltaTime, .05f));
        }
        public void Advance(float direction, bool jumpRequested, float dt)
        {
            if(State==RunState.Dying){AdvanceDeath(dt);return;}
            if(State != RunState.Running) return;
            Powers.Tick(dt);reviveGrace=Mathf.Max(0,reviveGrace-dt);
            steer = direction; jump = jumpRequested;
            Player.Tick(steer, jump, dt);
            float travel=Speed*dt;Distance += travel;scoreValue+=travel*Powers.Multiplier;Progress.Travel(travel,Score);
            Track.Tick(travel, dt);
            hudTime += dt; if(hudTime > .1f) { hudTime = 0; UI.UpdateHUD(); }
        }
        void LateUpdate()
        {
            if (!Player || !view) return;
            Vector3 target = new Vector3(Player.transform.position.x * .18f, 4.5f + Player.transform.position.y * .06f, -7.8f);
            float impact=State==RunState.Dying?Mathf.Max(0,1-DeathElapsed/.32f):0;
            target+=new Vector3(Mathf.Sin(DeathElapsed*85)*.14f,Mathf.Sin(DeathElapsed*63)*.08f,0)*impact;
            view.transform.rotation=Quaternion.Euler(18,0,Mathf.Sin(DeathElapsed*73)*2.2f*impact);
            view.fieldOfView=Mathf.Lerp(view.fieldOfView,State==RunState.Running?Mathf.Lerp(59,69,Mathf.InverseLerp(13.5f,37,Speed)):58,1-Mathf.Exp(-3*Time.unscaledDeltaTime));
            view.transform.position = Vector3.Lerp(view.transform.position, target, 1 - Mathf.Exp(-5 * Time.deltaTime));
        }
        void OnApplicationFocus(bool focus) { if(!focus && State == RunState.Running) SetState(RunState.Paused); }
        void OnApplicationQuit(){Progress?.Save();}
        void OnDestroy(){Time.timeScale=1;}
        public void Quit() {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }
#if UNITY_EDITOR
        public void ReloadProgressForChecks(){Progress=new RunnerProgress();Best=PlayerPrefs.GetInt("EndlessRunner.Best",0);UI.Show(State);}
        public bool TestControls;
        public float TestSteer;
        public bool TestJump;
#endif
    }
}






