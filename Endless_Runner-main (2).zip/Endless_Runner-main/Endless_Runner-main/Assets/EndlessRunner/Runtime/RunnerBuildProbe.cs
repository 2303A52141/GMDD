using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
namespace EndlessRunner
{
    // Runs only with the explicit --runner-self-test argument. Restores user saves on completion.
    public sealed class RunnerBuildProbe : MonoBehaviour
    {
        IEnumerator Start()
        {
            var game=GetComponent<RunnerGame>();var lines=new List<string>();
            string saved=PlayerPrefs.GetString(RunnerProgress.SaveKey,"");int best=PlayerPrefs.GetInt("EndlessRunner.Best",0);bool muted=game.Audio.Muted;
            string path=Path.Combine(Application.persistentDataPath,"standalone-checks.txt");var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length-1;i++)if(args[i]=="--runner-report")path=args[i+1];
            Application.runInBackground=true;var oldBackground=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;var keyboard=InputSystem.AddDevice<Keyboard>();
            void Check(bool ok,string name){lines.Add((ok?"PASS ":"FAIL ")+name);}
            yield return null;
            try
            {
                foreach(var key in new[]{Key.A,Key.D,Key.LeftArrow,Key.RightArrow,Key.Space,Key.UpArrow,Key.W,Key.DownArrow,Key.S})
                {
                    game.StartRun(0);yield return new WaitForSecondsRealtime(.15f);var before=game.Player.transform.position;
                    InputSystem.QueueStateEvent(keyboard,new KeyboardState(key));yield return new WaitForSecondsRealtime(.18f);var after=game.Player.transform.position;
                    bool slide=key==Key.DownArrow||key==Key.S;bool jump=key==Key.Space||key==Key.UpArrow||key==Key.W;
                    Check(slide?game.Player.Sliding&&game.Player.HitBounds.size.y<1:jump?after.y>before.y+.2f:key==Key.A||key==Key.LeftArrow?after.x<before.x-.1f:after.x>before.x+.1f,key+" standalone keyboard input");
                    InputSystem.QueueStateEvent(keyboard,new KeyboardState());yield return new WaitForSecondsRealtime(.05f);
                }
                game.TogglePause();float distance=game.Distance;yield return new WaitForSecondsRealtime(.15f);Check(game.Distance==distance&&Time.timeScale==0,"Standalone pause freezes distance");game.TogglePause();yield return new WaitForSecondsRealtime(.1f);Check(game.Distance>distance&&Time.timeScale==1,"Standalone resume");
                if(Array.IndexOf(args,"--runner-benchmark")>=0)
                {
                    game.StartRun(2);game.enabled=false;float end=Time.realtimeSinceStartup+25;var frames=new List<float>();int warmup=120;
                    while(Time.realtimeSinceStartup<end){game.Track.ClearNearPlayer(12);game.Advance(0,false,Mathf.Min(Time.unscaledDeltaTime,.05f));yield return null;if(--warmup<0)frames.Add(Time.unscaledDeltaTime);}
                    frames.Sort();float mean=frames.Count>0?frames.Average():1;lines.Add("PERFORMANCE "+Screen.width+"x"+Screen.height+" | "+SystemInfo.graphicsDeviceName+" | frames="+frames.Count+" | mean FPS="+(1/mean).ToString("F1")+" | p95 ms="+(frames[(int)(frames.Count*.95f)]*1000).ToString("F2")+" | p99 ms="+(frames[(int)(frames.Count*.99f)]*1000).ToString("F2")+" | recycled="+game.Track.Recycled);Check(game.Track.ChunkCount==7&&game.Track.Recycled>0,"Rendered benchmark keeps seven recycled chunks");
                    ScreenCapture.CaptureScreenshot(Path.Combine(Path.GetDirectoryName(path),"release-windows-gameplay.png"));yield return new WaitForEndOfFrame();yield return new WaitForSecondsRealtime(.3f);
                    if(game.Audio.Muted)game.Audio.ToggleMute();game.Audio.Play("coin");float peak=0;var samples=new float[1024];for(int i=0;i<30;i++){AudioListener.GetOutputData(samples,0);foreach(float sample in samples)peak=Mathf.Max(peak,Mathf.Abs(sample));yield return null;}Check(peak>0&&peak<.98f,"Standalone audio output is non-silent and unclipped, peak="+peak);
                }
            }
            finally
            {
                game.ShowMenu();if(game.Audio.Muted!=muted)game.Audio.ToggleMute();InputSystem.RemoveDevice(keyboard);InputSystem.settings.backgroundBehavior=oldBackground;game.enabled=false;Destroy(game);
                PlayerPrefs.SetString(RunnerProgress.SaveKey,saved);PlayerPrefs.SetInt("EndlessRunner.Best",best);PlayerPrefs.Save();
            }
            // Let OnDisable/OnDestroy complete before the final restore.
            yield return null;PlayerPrefs.SetString(RunnerProgress.SaveKey,saved);PlayerPrefs.SetInt("EndlessRunner.Best",best);PlayerPrefs.Save();Check(PlayerPrefs.GetString(RunnerProgress.SaveKey,"")==saved,"Standalone save restored");
            File.WriteAllText(path,string.Join("\n",lines));Debug.Log("ENDLESS_RUNNER_STANDALONE_CHECKS\n"+string.Join("\n",lines));Application.Quit(lines.Any(x=>x.StartsWith("FAIL"))?1:0);
        }
    }
}

