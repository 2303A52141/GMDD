using System;
using UnityEngine;
namespace EndlessRunner
{
    // Bounded row plans consumed by the existing seven-segment pool. No GameObjects are allocated on recycling.
    public sealed class DesertPatternPlanner
    {
        public sealed class Row
        {
            public float Distance, Gap, PlanningSpeed;
            public int SafeLane, PreviousSafeLane, CoinCount, Pattern;
            public int[] HazardLanes=new int[2], HazardTypes=new int[2];
            public int HazardCount;
            public bool Gem;
            public Vector3[] Coins=new Vector3[5];
        }
        readonly System.Random random; readonly RunnerDifficulty difficulty; readonly float boost, laneSeconds, jumpSeconds, jumpVelocity, jumpGravity;
        int safeLane, streak; float nextDistance;
        public float NextDistance=>nextDistance;
        public int LastSafeLane=>safeLane;
        public int Seed {get;}
        public int FallbackCount {get;private set;}
        public DesertPatternPlanner(int mode,int seed,float maximumBoost,float lateralSpeed=12,float jumpSpeed=10,float gravity=26)
        {
            Seed=seed;random=new System.Random(seed);difficulty=RunnerDifficulty.For(mode);boost=maximumBoost;
            laneSeconds=RunnerAvatar.LaneSpacing/Mathf.Max(1,lateralSpeed);jumpVelocity=Mathf.Max(1,jumpSpeed);jumpGravity=Mathf.Max(1,gravity);jumpSeconds=2*jumpVelocity/jumpGravity;
            safeLane=random.Next(3);nextDistance=Mathf.Max(24,difficulty.StartSpeed*1.8f)+R(0,3);
        }
        float R(float low,float high)=>Mathf.Lerp(low,high,(float)random.NextDouble());
        public Row Next()
        {
            var row=new Row{Distance=nextDistance,PreviousSafeLane=safeLane};
            int chosen=Mathf.Clamp(safeLane+random.Next(-1,2),0,2);
            if((streak>=1||random.NextDouble()<difficulty.DoubleHazardChance)&&chosen==safeLane)chosen=safeLane==0?1:safeLane==2?1:random.Next(2)*2;
            streak=chosen==safeLane?streak+1:0;safeLane=chosen;row.SafeLane=chosen;
            // Conservative speed at the row's far edge, including a possible boost, protects already-spawned rows.
            row.PlanningSpeed=difficulty.SpeedAt(row.Distance+48)*boost;
            row.Gap=Mathf.Max(difficulty.MinimumGap,row.PlanningSpeed*(difficulty.ReactionSeconds+laneSeconds)+3)+R(0,difficulty.GapJitter);
            // Every row contains hazards; the first arrives after roughly two seconds.
            row.HazardCount=random.NextDouble()<difficulty.DoubleHazardChance*Mathf.Lerp(.85f,1,Mathf.Clamp01(row.Distance/(difficulty.MetresPerSpeed*2)))?2:1;
            int blocked=(safeLane+1+random.Next(2))%3;
            for(int i=0;i<row.HazardCount;i++)
            {
                row.HazardLanes[i]=i==0?blocked:3-safeLane-blocked;
                row.HazardTypes[i]=random.NextDouble()<difficulty.VehicleChance?5:ChooseGroundHazard();
                if(i==1&&row.HazardTypes[i]==row.HazardTypes[0])row.HazardTypes[i]=(row.HazardTypes[i]+1+random.Next(6))%7;
            }
            row.CoinCount=random.Next(2,5);row.Gem=random.NextDouble()<difficulty.GemChance;
            int roll=random.Next(100);row.Pattern=roll<40?0:roll<65?1:roll<85?2:3;
            float spacing=R(1.9f,3.1f),start=-R(4,7);
            for(int i=0;i<5;i++)row.Coins[i]=new Vector3((safeLane-1)*RunnerAvatar.LaneSpacing,1.1f,row.Distance+start+i*spacing);
            if(row.Pattern==1 && row.PreviousSafeLane!=safeLane)
            {
                // One readable lane change; no coin sits in a blocked lane close to a hazard.
                row.Coins[0]=new Vector3((row.PreviousSafeLane-1)*3,1.1f,row.Distance-Mathf.Max(12,row.PlanningSpeed*(laneSeconds+.08f)+2));
                for(int i=1;i<5;i++)row.Coins[i]=new Vector3((safeLane-1)*3,1.1f,row.Distance-2+(i-1)*2.5f);
            }
            else if(row.Pattern==2)
            {
                // Sample one reachable ballistic jump; length scales with travel speed.
                for(int i=0;i<5;i++){float time=jumpSeconds*(.12f+i*.17f);row.Coins[i]=new Vector3((safeLane-1)*3,Mathf.Min(3,1.1f+jumpVelocity*time-.5f*jumpGravity*time*time),row.Distance+row.PlanningSpeed*(time-jumpSeconds*.5f));}
            }
            else if(row.Pattern==3 && row.HazardCount==1 && Mathf.Abs((3-safeLane-row.HazardLanes[0])-safeLane)==1)
            {
                // Alternate the two unblocked adjacent lanes; never route coins through the hazard.
                int adjacent=3-safeLane-row.HazardLanes[0];
                float step=Mathf.Max(4,row.PlanningSpeed*(laneSeconds+.10f)+.5f);row.CoinCount=3;row.Gem=false;
                row.Coins[0]=new Vector3((safeLane-1)*3,1.1f,row.Distance-step);
                row.Coins[1]=new Vector3((adjacent-1)*3,1.1f,row.Distance);
                row.Coins[2]=new Vector3((safeLane-1)*3,1.1f,row.Distance+step);
            }
            else if(row.Pattern==3){row.Pattern=1;for(int i=0;i<5;i++){var p=row.Coins[i];p.z+=i%2==0?-.35f:.35f;row.Coins[i]=p;}}
                        if(!Valid(row))
            {
                FallbackCount++;row.HazardCount=0;row.Pattern=0;row.CoinCount=3;row.Gem=false;
                for(int i=0;i<5;i++)row.Coins[i]=new Vector3((safeLane-1)*3,1.1f,row.Distance-4+i*2);
            }
            nextDistance+=row.Gap;return row;
        }
        public bool Valid(Row row)
        {
            if(row.SafeLane<0||row.SafeLane>2||row.HazardCount>2||Mathf.Abs(row.SafeLane-row.PreviousSafeLane)>1||row.Gap<row.PlanningSpeed*(difficulty.ReactionSeconds+laneSeconds)+2.99f)return false;
            for(int h=0;h<row.HazardCount;h++)if(row.HazardLanes[h]==row.SafeLane||row.HazardTypes[h]<0||row.HazardTypes[h]>6||(h>0&&row.HazardLanes[h]==row.HazardLanes[h-1]))return false;
            for(int i=0;i<5;i++)
            {
                if(i<4?i>=row.CoinCount:!row.Gem)continue;var p=row.Coins[i];
                if(Mathf.Abs(p.x)>3||Mathf.Abs(p.x/3-Mathf.Round(p.x/3))>.01f||p.y<.7f||p.y>3)return false;
                for(int h=0;h<row.HazardCount;h++)if(Mathf.Abs(p.x-(row.HazardLanes[h]-1)*3)<1.45f&&Mathf.Abs(p.z-row.Distance)<2)return false;
                if(i>0&&i<row.CoinCount&&Mathf.Abs(p.x-row.Coins[i-1].x)>.1f&&(p.z-row.Coins[i-1].z)/row.PlanningSpeed<Mathf.Abs(p.x-row.Coins[i-1].x)/RunnerAvatar.LaneSpacing*laneSeconds)return false;
            }
            return true;
        }
        int ChooseGroundHazard(){int pick=random.Next(6);return pick==5?6:pick;}
    }
}






