using System.Collections.Generic;
using UnityEngine;
namespace EndlessRunner
{
    // Finite geometry created once per pooled segment. Recycling never allocates scenery.
    public sealed class DesertScenery : MonoBehaviour
    {
        readonly List<Mesh> owned=new List<Mesh>();
        Material[] mats; System.Random rng;
        float R(float a,float b)=>Mathf.Lerp(a,b,(float)rng.NextDouble());
        public static void Build(Transform parent,int seed,Material[] palette){var s=parent.gameObject.AddComponent<DesertScenery>();s.mats=palette;s.rng=new System.Random(919+seed*137);s.Create(seed);}
        GameObject MeshObject(string name,Mesh mesh,Vector3 position,Vector3 scale,Material[] materials){var go=new GameObject(name,typeof(MeshFilter),typeof(MeshRenderer));go.transform.SetParent(transform,false);go.transform.localPosition=position;go.transform.localScale=scale;go.GetComponent<MeshFilter>().sharedMesh=mesh;go.GetComponent<MeshRenderer>().sharedMaterials=materials;return go;}
        void Create(int seed)
        {
            for(int side=-1;side<=1;side+=2)
            {
                var dune=Dune(side,seed);owned.Add(dune);MeshObject("Wind-carved dune field",dune,Vector3.zero,Vector3.one,new[]{mats[0]});
                for(int n=0;n<3;n++){var cliff=Cliff(12,seed*7+n);owned.Add(cliff);var o=MeshObject("Layered canyon escarpment",cliff,new Vector3(side*R(34,70),-.25f,R(2,46)),new Vector3(R(10,20),R(11,28),R(10,19)),new[]{mats[3],mats[11],mats[2]});o.transform.localRotation=Quaternion.Euler(0,R(0,360),0);}
                var stone=Cliff(9,seed+34);owned.Add(stone);
                for(int n=0;n<10;n++){float z=R(1,47),x=side*R(7,27);var o=MeshObject("Eroded sandstone outcrop",stone,new Vector3(x,-.18f,z),new Vector3(R(.4f,2),R(.3f,1.6f),R(.6f,2)),new[]{mats[2],mats[3],mats[2]});o.transform.localRotation=Quaternion.Euler(0,R(0,360),R(-10,10));}
                for(int n=0;n<6;n++){var c=new GameObject("Desert vegetation").transform;c.SetParent(transform,false);c.localPosition=new Vector3(side*R(8,24),0,R(2,46));float size=R(.65f,1.5f);c.localScale=Vector3.one*size;c.localRotation=Quaternion.Euler(0,R(0,360),R(-5,5));
                    RunnerAvatar.Shape("Ribbed saguaro",PrimitiveType.Capsule,c,new Vector3(0,1.3f,0),new Vector3(.44f,1.3f,.44f),mats[10]);
                    for(int arm=-1;arm<=1;arm+=2){float y=arm<0?1.1f:1.8f;var joint=RunnerAvatar.Shape("Curved cactus elbow",PrimitiveType.Capsule,c,new Vector3(arm*.39f,y,0),new Vector3(.27f,.38f,.27f),mats[10]);joint.transform.localRotation=Quaternion.Euler(0,0,arm*65);RunnerAvatar.Shape("Cactus branch",PrimitiveType.Capsule,c,new Vector3(arm*.63f,y+.35f,0),new Vector3(.25f,.5f,.25f),mats[10]);}
                    for(int rib=0;rib<6;rib++){float a=rib*Mathf.PI/3;RunnerAvatar.Shape("Cactus ridge",PrimitiveType.Capsule,c,new Vector3(Mathf.Cos(a)*.2f,1.3f,Mathf.Sin(a)*.2f),new Vector3(.025f,1.04f,.025f),mats[8]);}
                }
                for(int n=0;n<10;n++){var bush=new GameObject("Dry grass tuft").transform;bush.SetParent(transform,false);bush.localPosition=new Vector3(side*R(6.2f,17),0,R(1,47));for(int b=0;b<5;b++){var twig=RunnerAvatar.Shape("Sun-dried frond",PrimitiveType.Capsule,bush,new Vector3(R(-.22f,.22f),.22f,R(-.2f,.2f)),new Vector3(.035f,R(.2f,.4f),.035f),mats[8]);twig.transform.localRotation=Quaternion.Euler(R(-40,40),R(0,360),R(-40,40));}}
            }
            // Worn lane guide stones align with targets -3, 0 and +3.
            for(int lane=-1;lane<=1;lane+=2)for(int z=1;z<48;z+=8)RunnerAvatar.Shape("Worn lane guide",PrimitiveType.Cube,transform,new Vector3(lane*1.5f,.012f,z),new Vector3(.035f,.012f,1.4f),mats[0]);
            for(int side=-1;side<=1;side+=2)for(int z=2;z<48;z+=3){var rock=RunnerAvatar.Shape("Track edge pebble",PrimitiveType.Sphere,transform,new Vector3(side*5.55f,.05f,z),new Vector3(R(.12f,.25f),.1f,R(.2f,.5f)),mats[2]);}
        }
        Mesh Dune(int side,int seed)
        {
            const int nx=30,nz=24;var v=new Vector3[(nx+1)*(nz+1)];var uv=new Vector2[v.Length];var t=new List<int>();
            for(int z=0;z<=nz;z++)for(int x=0;x<=nx;x++){float xx=5.65f+x*2.6f,zz=z*2f;float edge=Mathf.SmoothStep(0,1,(xx-6)/15);float seam=Mathf.Pow(Mathf.Sin(zz/48*Mathf.PI),2);float h=edge*(.3f+seam*(2+Mathf.PerlinNoise(xx*.035f+seed*3,zz*.035f)*7+Mathf.Sin(xx*.13f+zz*.055f)*1.5f));int k=z*(nx+1)+x;v[k]=new Vector3(xx*side,h-.12f,zz);uv[k]=new Vector2(xx*.08f,zz*.08f);if(x<nx&&z<nz){int a=k,b=k+1,c=k+nx+1,d=c+1;if(side>0){t.Add(a);t.Add(c);t.Add(b);t.Add(b);t.Add(c);t.Add(d);}else{t.Add(a);t.Add(b);t.Add(c);t.Add(b);t.Add(d);t.Add(c);}}}
            var m=new Mesh{name="Sculpted sand dunes"};m.vertices=v;m.uv=uv;m.SetTriangles(t,0);m.RecalculateNormals();m.RecalculateBounds();return m;
        }
        Mesh Cliff(int sides,int seed)
        {
            var v=new List<Vector3>();var uv=new List<Vector2>();var tris=new[]{new List<int>(),new List<int>(),new List<int>()};float[] widths={1,.92f,.75f,.81f,.60f,.64f,.41f,.38f};
            for(int ring=0;ring<8;ring++)for(int i=0;i<=sides;i++){float a=i*Mathf.PI*2/sides;float noise=.85f+.18f*Mathf.PerlinNoise(Mathf.Cos(a)*2+seed,Mathf.Sin(a)*2+seed);v.Add(new Vector3(Mathf.Cos(a)*widths[ring]*noise,ring/7f,Mathf.Sin(a)*widths[ring]*noise));uv.Add(new Vector2(i/(float)sides,ring*.3f));}
            for(int r=0;r<7;r++)for(int i=0;i<sides;i++){int a=r*(sides+1)+i,b=a+1,c=a+sides+1,d=c+1;var t=tris[r%3];t.Add(a);t.Add(c);t.Add(b);t.Add(b);t.Add(c);t.Add(d);}
            int center=v.Count;v.Add(Vector3.up);uv.Add(Vector2.one*.5f);for(int i=0;i<sides;i++){tris[0].Add(7*(sides+1)+i);tris[0].Add(center);tris[0].Add(7*(sides+1)+i+1);}
            var m=new Mesh{name="Stratified sandstone"};m.SetVertices(v);m.SetUVs(0,uv);m.subMeshCount=3;for(int i=0;i<3;i++)m.SetTriangles(tris[i],i);m.RecalculateNormals();m.RecalculateBounds();return m;
        }
        void OnDestroy(){foreach(var m in owned)if(m)Destroy(m);}
    }
}
