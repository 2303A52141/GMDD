using System.Collections.Generic;
using UnityEngine;
namespace EndlessRunner
{
    public sealed class RunnerAudio : MonoBehaviour
    {
        readonly Dictionary<string,AudioClip> clips=new Dictionary<string,AudioClip>();
        AudioSource source,footsteps,music,wind; RunnerGame game;
        public bool Muted {get;private set;}
        public int ClipCount=>clips.Count;
        public float MaximumSamplePeak {get;private set;}
        public bool AmbientPlaying=>wind&&wind.isPlaying&&music&&music.isPlaying;
        void Awake()
        {
            game=GetComponent<RunnerGame>();source=Source(game.effectsVolume);footsteps=Source(game.effectsVolume*.65f);
            Tone("slide",180,60,.48f,.2f,true);Tone("coin",880,1320,.14f,.22f);Tone("gem",1100,2200,.30f,.25f);Tone("jump",250,650,.22f,.22f);
            Tone("crash",130,35,.45f,.45f,true);Tone("step",90,40,.075f,.17f,true);Tone("start",440,880,.25f,.22f);
            Tone("click",600,750,.07f,.18f);Tone("land",100,50,.14f,.23f,true);Tone("power",500,1500,.35f,.3f);Tone("expire",600,300,.2f,.15f);Tone("shield",1200,400,.25f,.25f);
            wind=Source(.18f);wind.loop=true;wind.clip=Ambient(false);wind.Play();
            music=Source(.18f);music.loop=true;music.clip=game.backgroundMusic?game.backgroundMusic:Ambient(true);music.Play();
            Muted=PlayerPrefs.GetInt("EndlessRunner.Muted",0)==1;ApplyMute();
        }
        AudioSource Source(float volume){var s=gameObject.AddComponent<AudioSource>();s.spatialBlend=0;s.volume=volume;s.playOnAwake=false;return s;}
        AudioClip Store(string name,float[] data,int rate)
        {
            foreach(float sample in data)MaximumSamplePeak=Mathf.Max(MaximumSamplePeak,Mathf.Abs(sample));
            var clip=AudioClip.Create(name,data.Length,1,rate,false);clip.SetData(data,0);clips.Add(name,clip);return clip;
        }
        void Tone(string name,float from,float to,float duration,float volume,bool noise=false)
        {
            const int rate=22050;var data=new float[Mathf.CeilToInt(rate*duration)];var rng=new System.Random(42);float phase=0,filtered=0;
            for(int i=0;i<data.Length;i++){float t=(float)i/data.Length;phase+=2*Mathf.PI*Mathf.Lerp(from,to,t)/rate;filtered=Mathf.Lerp(filtered,(float)(rng.NextDouble()*2-1),.18f);float wave=noise?filtered*.8f+Mathf.Sin(phase)*.2f:Mathf.Sin(phase)*.8f+Mathf.Sin(phase*2)*.2f;data[i]=wave*Mathf.Sin(Mathf.PI*t)*Mathf.Pow(1-t,1.6f)*volume;}
            Store(name,data,rate);
        }
        AudioClip Ambient(bool melody)
        {
            const int rate=22050,seconds=16;var data=new float[rate*seconds];var rng=new System.Random(932);float filtered=0;
            int[] notes={62,69,65,72,69,65,62,57,62,65,69,74,72,69,65,57};
            for(int i=0;i<data.Length;i++)
            {
                float t=i/(float)rate;
                if(melody){int n=Mathf.FloorToInt(t);float at=t-n;float f=440*Mathf.Pow(2,(notes[n]-69)/12f);float envelope=(1-Mathf.Exp(-at*90))*Mathf.Exp(-at*4.5f);float pluck=(Mathf.Sin(2*Mathf.PI*f*at)+.23f*Mathf.Sin(2*Mathf.PI*f*2*at)+.08f*Mathf.Sin(2*Mathf.PI*f*3*at))*.15f*envelope;float drone=Mathf.Sin(2*Mathf.PI*110*t)*.025f+Mathf.Sin(2*Mathf.PI*165*t)*.018f;data[i]=pluck+drone;}
                else{filtered=Mathf.Lerp(filtered,(float)(rng.NextDouble()*2-1),.035f);data[i]=filtered*(.45f+.2f*Mathf.Sin(t*Mathf.PI/4));}
            }
            // Equal-power taper prevents an audible loop-boundary click.
            int fade=rate/20;for(int i=0;i<fade;i++){float gain=i/(float)fade;data[i]*=gain;data[data.Length-1-i]*=gain;}
            return Store(melody?"Original desert plucked theme":"Desert wind",data,rate);
        }
        void Update()
        {
            if(!game)return;bool paused=game.State==RunState.Paused;
            music.volume=Mathf.MoveTowards(music.volume,paused?.075f:game.State==RunState.Running?.14f:.22f,Time.unscaledDeltaTime*.25f);
            wind.volume=Mathf.MoveTowards(wind.volume,paused?.06f:.18f,Time.unscaledDeltaTime*.25f);
        }
        public void Play(string name)
        {
            if(Muted||!clips.TryGetValue(name,out var clip))return;
            if(name=="step"){footsteps.pitch=Random.Range(.92f,1.08f);footsteps.PlayOneShot(clip);}else source.PlayOneShot(clip);
        }
        public void ToggleMute(){Muted=!Muted;PlayerPrefs.SetInt("EndlessRunner.Muted",Muted?1:0);PlayerPrefs.Save();ApplyMute();}
        void ApplyMute(){foreach(var s in new[]{source,footsteps,music,wind})if(s)s.mute=Muted;}
        void OnDestroy(){foreach(var clip in clips.Values)Destroy(clip);}
    }
}
