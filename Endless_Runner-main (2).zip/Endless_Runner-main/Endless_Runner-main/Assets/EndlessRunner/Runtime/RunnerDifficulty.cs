using UnityEngine;
namespace EndlessRunner
{
    // Single authority for speed, progression and procedural difficulty. Distances are metres.
    public sealed class RunnerDifficulty
    {
        public readonly string Name;
        public readonly float StartSpeed, MaximumSpeed, MetresPerSpeed, ReactionSeconds, MinimumGap, GapJitter, DoubleHazardChance, EmptyRowChance, VehicleChance, GemChance;
        RunnerDifficulty(string name,float start,float maximum,float progression,float reaction,float gap,float jitter,float doubles,float empty,float vehicles,float gems)
        {Name=name;StartSpeed=start;MaximumSpeed=maximum;MetresPerSpeed=progression;ReactionSeconds=reaction;MinimumGap=gap;GapJitter=jitter;DoubleHazardChance=doubles;EmptyRowChance=empty;VehicleChance=vehicles;GemChance=gems;}
        public float SpeedAt(float distance)=>Mathf.Min(MaximumSpeed,StartSpeed+Mathf.Max(0,distance)/MetresPerSpeed);
        public float SafeGap(float distance,float boost)=>Mathf.Max(MinimumGap,SpeedAt(distance)*boost*ReactionSeconds+4f);
        public static readonly RunnerDifficulty[] Modes={
            new RunnerDifficulty("EASY",13.5f,19,650,.85f,16.5f,3,.35f,0,.12f,.20f),
            new RunnerDifficulty("NORMAL",18,27,260,.62f,17,2.5f,.70f,0,.23f,.30f),
            new RunnerDifficulty("FAST",27,37,170,.40f,18,2,.94f,0,.35f,.40f)
        };
        public static RunnerDifficulty For(int mode)=>Modes[Mathf.Clamp(mode,0,2)];
    }
}


