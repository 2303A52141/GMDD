using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using System.Linq;
using System.IO;
namespace EndlessRunner.Editor
{
    public static class ReleaseUpgrade
    {
        const string Folder="Assets/EndlessRunner/Explorer/Animation";
        static void Curve(AnimationClip clip,string path,string property,float[] values,float duration)
        {
            var keys=new Keyframe[values.Length];for(int i=0;i<values.Length;i++)keys[i]=new Keyframe(duration*i/(values.Length-1),values[i]);
            var curve=new AnimationCurve(keys);for(int i=0;i<keys.Length;i++)AnimationUtility.SetKeyBroken(curve,i,false);
            clip.SetCurve(path,typeof(Transform),property,curve);
        }
        public static string Apply()
        {
            if(EditorApplication.isPlaying)throw new System.Exception("Stop Play first");
            Directory.CreateDirectory(Folder);AssetDatabase.Refresh();
            var game=Object.FindFirstObjectByType<RunnerGame>();
            string path=AssetDatabase.GetAssetPath(game.runnerPrefab);var root=PrefabUtility.LoadPrefabContents(path);
            try
            {
                var avatar=root.GetComponent<RunnerAvatar>();var visual=root.GetComponent<ExplorerVisual>();
                // Preserve the model and skeleton; consolidate rigid parts into a bone-weighted skin.
                var filters=root.GetComponentsInChildren<MeshFilter>();
                if(filters.Length>0)
                {
                    var bones=new List<Transform>();var materials=new List<Material>();var vertices=new List<Vector3>();var normals=new List<Vector3>();var uvs=new List<Vector2>();var weights=new List<BoneWeight>();var triangles=new List<List<int>>();
                    foreach(var f in filters)
                    {
                        var renderer=f.GetComponent<MeshRenderer>();if(!renderer)continue;
                        Transform bone=f.transform.parent;int boneIndex=bones.IndexOf(bone);if(boneIndex<0){boneIndex=bones.Count;bones.Add(bone);}
                        var mat=renderer.sharedMaterial;int materialIndex=materials.IndexOf(mat);if(materialIndex<0){materialIndex=materials.Count;materials.Add(mat);triangles.Add(new List<int>());}
                        var mesh=f.sharedMesh;int offset=vertices.Count;var matrix=root.transform.worldToLocalMatrix*f.transform.localToWorldMatrix;
                        for(int i=0;i<mesh.vertexCount;i++){vertices.Add(matrix.MultiplyPoint3x4(mesh.vertices[i]));normals.Add(matrix.MultiplyVector(mesh.normals[i]).normalized);uvs.Add(mesh.uv[i]);weights.Add(new BoneWeight{boneIndex0=boneIndex,weight0=1});}
                        foreach(int index in mesh.triangles)triangles[materialIndex].Add(offset+index);
                    }
                    var skinMesh=new Mesh{name="Ari skinned expedition mesh"};skinMesh.SetVertices(vertices);skinMesh.SetNormals(normals);skinMesh.SetUVs(0,uvs);skinMesh.boneWeights=weights.ToArray();skinMesh.bindposes=bones.Select(b=>b.worldToLocalMatrix*root.transform.localToWorldMatrix).ToArray();skinMesh.subMeshCount=materials.Count;for(int i=0;i<materials.Count;i++)skinMesh.SetTriangles(triangles[i],i);skinMesh.RecalculateBounds();
                    string meshPath=Folder+"/AriSkin.asset";var saved=AssetDatabase.LoadAssetAtPath<Mesh>(meshPath);if(saved){EditorUtility.CopySerialized(skinMesh,saved);Object.DestroyImmediate(skinMesh);skinMesh=saved;EditorUtility.SetDirty(saved);}else AssetDatabase.CreateAsset(skinMesh,meshPath);
                    var skin=root.GetComponent<SkinnedMeshRenderer>();if(!skin)skin=root.AddComponent<SkinnedMeshRenderer>();skin.sharedMesh=skinMesh;skin.bones=bones.ToArray();skin.rootBone=avatar.body;skin.sharedMaterials=materials.ToArray();skin.localBounds=new Bounds(Vector3.up,Vector3.one*6);skin.updateWhenOffscreen=false;
                    foreach(var f in filters){Object.DestroyImmediate(f.GetComponent<MeshRenderer>());Object.DestroyImmediate(f);}
                }
                var joints=new[]{avatar.body,avatar.leftLeg,avatar.rightLeg,avatar.leftArm,avatar.rightArm,visual.leftKnee,visual.rightKnee,visual.leftElbow,visual.rightElbow,visual.head,visual.scarf};
                string[] paths=joints.Select(t=>AnimationUtility.CalculateTransformPath(t,root.transform)).ToArray();
                string controllerPath=Folder+"/Ari.controller";var controller=AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath);if(!controller)controller=AnimatorController.CreateAnimatorControllerAtPath(controllerPath);
                foreach(var state in controller.layers[0].stateMachine.states)controller.layers[0].stateMachine.RemoveState(state.state);
                if(!controller.parameters.Any(p=>p.name=="RunSpeed"))controller.AddParameter("RunSpeed",AnimatorControllerParameterType.Float);
                foreach(string name in new[]{"Idle","Run","Jump","Landing","Slide","Hit"})
                {
                    float duration=name=="Run"?.65f:name=="Idle"?2.4f:name=="Jump"?.7f:name=="Slide"?.8f:name=="Hit"?.5f:.16f;
                    var clip=new AnimationClip{name=name,frameRate=60};
                    for(int i=0;i<joints.Length;i++)foreach(string axis in new[]{"x","y","z"})Curve(clip,paths[i],"localEulerAnglesRaw."+axis,new[]{0f,0f},duration);
                    Curve(clip,paths[0],"m_LocalPosition.y",new[]{0f,0f},duration);
                    if(name=="Idle") {Curve(clip,paths[0],"localEulerAnglesRaw.y",new[]{155f,155f},duration);Curve(clip,paths[0],"m_LocalPosition.y",new[]{0f,.012f,0f},duration);Curve(clip,paths[9],"localEulerAnglesRaw.y",new[]{-4f,4f,-4f},duration);}
                    if(name=="Run")
                    {
                        Curve(clip,paths[0],"localEulerAnglesRaw.x",new[]{7f,7f},duration);Curve(clip,paths[0],"m_LocalPosition.y",new[]{0f,.035f,0f,.035f,0f},duration);
                        Curve(clip,paths[1],"localEulerAnglesRaw.x",new[]{-34f,0f,34f,0f,-34f},duration);Curve(clip,paths[2],"localEulerAnglesRaw.x",new[]{34f,0f,-34f,0f,34f},duration);
                        Curve(clip,paths[3],"localEulerAnglesRaw.x",new[]{28f,0f,-28f,0f,28f},duration);Curve(clip,paths[4],"localEulerAnglesRaw.x",new[]{-28f,0f,28f,0f,-28f},duration);
                        Curve(clip,paths[5],"localEulerAnglesRaw.x",new[]{18f,62f,8f,18f,18f},duration);Curve(clip,paths[6],"localEulerAnglesRaw.x",new[]{8f,18f,18f,62f,8f},duration);
                        foreach(int i in new[]{7,8})Curve(clip,paths[i],"localEulerAnglesRaw.x",new[]{-48f,-38f,-48f},duration);
                        Curve(clip,paths[10],"localEulerAnglesRaw.x",new[]{-12f,12f,-12f,12f,-12f},duration);
                    }
                    if(name=="Jump") {Curve(clip,paths[1],"localEulerAnglesRaw.x",new[]{-35f,-45f,-25f},duration);Curve(clip,paths[2],"localEulerAnglesRaw.x",new[]{-15f,-25f,-10f},duration);Curve(clip,paths[5],"localEulerAnglesRaw.x",new[]{65f,80f,45f},duration);Curve(clip,paths[6],"localEulerAnglesRaw.x",new[]{30f,45f,20f},duration);foreach(int i in new[]{7,8})Curve(clip,paths[i],"localEulerAnglesRaw.x",new[]{-70f,-70f},duration);}
                    if(name=="Landing"){Curve(clip,paths[0],"m_LocalPosition.y",new[]{-.09f,0f},duration);foreach(int i in new[]{5,6})Curve(clip,paths[i],"localEulerAnglesRaw.x",new[]{35f,10f},duration);}
                    if(name=="Slide"){Curve(clip,paths[0],"m_LocalPosition.y",new[]{-.35f,-.35f},duration);Curve(clip,paths[0],"localEulerAnglesRaw.x",new[]{55f,55f},duration);foreach(int i in new[]{1,2})Curve(clip,paths[i],"localEulerAnglesRaw.x",new[]{-135f,-135f},duration);foreach(int i in new[]{5,6})Curve(clip,paths[i],"localEulerAnglesRaw.x",new[]{155f,155f},duration);Curve(clip,paths[9],"localEulerAnglesRaw.x",new[]{-35f,-35f},duration);foreach(int i in new[]{7,8})Curve(clip,paths[i],"localEulerAnglesRaw.x",new[]{-75f,-75f},duration);}
                    if(name=="Hit"){Curve(clip,paths[0],"localEulerAnglesRaw.z",new[]{-20f,-55f,-55f},duration);Curve(clip,paths[0],"localEulerAnglesRaw.x",new[]{-10f,-20f,-20f},duration);}
                    var settings=AnimationUtility.GetAnimationClipSettings(clip);settings.loopTime=name=="Idle"||name=="Run";AnimationUtility.SetAnimationClipSettings(clip,settings);
                    string clipPath=Folder+"/"+name+".anim";var existing=AssetDatabase.LoadAssetAtPath<AnimationClip>(clipPath);if(existing){EditorUtility.CopySerialized(clip,existing);Object.DestroyImmediate(clip);clip=existing;EditorUtility.SetDirty(clip);}else AssetDatabase.CreateAsset(clip,clipPath);
                    var state=controller.layers[0].stateMachine.AddState(name);state.motion=clip;if(name=="Run"){state.speedParameter="RunSpeed";state.speedParameterActive=true;}if(name=="Idle")controller.layers[0].stateMachine.defaultState=state;
                }
                var animator=root.GetComponent<Animator>();if(!animator)animator=root.AddComponent<Animator>();animator.runtimeAnimatorController=controller;animator.applyRootMotion=false;animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
                PrefabUtility.SaveAsPrefabAsset(root,path);EditorUtility.SetDirty(controller);
            }
            finally{PrefabUtility.UnloadPrefabContents(root);}
            var gate=new GameObject("Overhead gate - slide");var box=gate.AddComponent<BoxCollider>();box.center=new Vector3(0,1.8f,0);box.size=new Vector3(2.2f,.85f,.65f);
            RunnerAvatar.Shape("Crossbar",PrimitiveType.Cube,gate.transform,box.center,box.size,game.palette[3]);
            for(int side=-1;side<=1;side+=2)RunnerAvatar.Shape("Gate post",PrimitiveType.Cube,gate.transform,new Vector3(side*1.3f,1.1f,0),new Vector3(.18f,2.2f,.28f),game.palette[9]);
            for(int i=-4;i<=4;i++){var stripe=RunnerAvatar.Shape("Warning stripe",PrimitiveType.Cube,gate.transform,new Vector3(i*.24f,1.8f,-.34f),new Vector3(.12f,.75f,.025f),game.palette[8]);stripe.transform.localRotation=Quaternion.Euler(0,0,-18);}
            var gatePrefab=PrefabUtility.SaveAsPrefabAsset(gate,"Assets/EndlessRunner/Prefabs/Obstacles/SlideGate.prefab");Object.DestroyImmediate(gate);var list=game.obstaclePrefabs.Where(p=>p&&p!=gatePrefab).ToList();list.Add(gatePrefab);game.obstaclePrefabs=list.ToArray();EditorUtility.SetDirty(game);EditorSceneManager.MarkSceneDirty(game.gameObject.scene);EditorSceneManager.SaveOpenScenes();AssetDatabase.SaveAssets();return "Skinned explorer, six authored animation clips, Animator controller and slide gate installed";
        }
    }
}


