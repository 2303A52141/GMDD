using System.IO;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;

namespace EndlessRunner.Editor
{
    public static class RunnerUpgrade
    {
        [MenuItem("Endless Runner/Apply Feature Upgrade")]
        public static void Apply()
        {
            if(EditorApplication.isPlaying)throw new System.Exception("Stop Play mode first");
            var game=Object.FindFirstObjectByType<RunnerGame>();
            if(!game)throw new System.Exception("Open the existing EndlessRunner scene first");
            Directory.CreateDirectory("Assets/EndlessRunner/Prefabs/Obstacles");AssetDatabase.Refresh();
            game.obstaclePrefabs=new GameObject[6];
            string[] names={"Rock","Cactus","Block","Barrier","FallenLog","DesertVehicle"};
            for(int i=0;i<6;i++)
            {
                var root=new GameObject(names[i]);
                System.Action<string,PrimitiveType,Vector3,Vector3,int> part=(name,type,pos,scale,mat)=>RunnerAvatar.Shape(name,type,root.transform,pos,scale,game.palette[mat]);
                var box=root.AddComponent<BoxCollider>();box.isTrigger=true;
                switch(i)
                {
                    case 0:
                        part("Sandstone rock",PrimitiveType.Sphere,new Vector3(0,.55f,0),new Vector3(1.7f,1.1f,1.4f),2);
                        box.center=new Vector3(0,.55f,0);box.size=new Vector3(1.6f,1.05f,1.35f);break;
                    case 1:
                        part("Cactus stem",PrimitiveType.Capsule,new Vector3(0,1.4f,0),new Vector3(.55f,1.4f,.55f),10);
                        part("Left branch",PrimitiveType.Cube,new Vector3(-.45f,1.3f,0),new Vector3(.8f,.3f,.3f),10);
                        part("Left tip",PrimitiveType.Capsule,new Vector3(-.75f,1.7f,0),new Vector3(.3f,.5f,.3f),10);
                        part("Right branch",PrimitiveType.Cube,new Vector3(.45f,1.8f,0),new Vector3(.8f,.3f,.3f),10);
                        part("Right tip",PrimitiveType.Capsule,new Vector3(.75f,2.1f,0),new Vector3(.3f,.4f,.3f),10);
                        box.center=new Vector3(0,1.4f,0);box.size=new Vector3(1.8f,2.8f,.6f);break;
                    case 2:
                        part("Stone block",PrimitiveType.Cube,new Vector3(0,.6f,0),new Vector3(1.65f,1.2f,1.4f),11);
                        part("Carved stripe",PrimitiveType.Cube,new Vector3(0,.85f,-.71f),new Vector3(1.5f,.12f,.03f),8);
                        box.center=new Vector3(0,.6f,0);box.size=new Vector3(1.65f,1.2f,1.4f);break;
                    case 3:
                        part("Left support",PrimitiveType.Cube,new Vector3(-.85f,.45f,0),new Vector3(.15f,.9f,.2f),9);
                        part("Right support",PrimitiveType.Cube,new Vector3(.85f,.45f,0),new Vector3(.15f,.9f,.2f),9);
                        part("Warning barrier",PrimitiveType.Cube,new Vector3(0,.7f,0),new Vector3(1.9f,.4f,.25f),4);
                        for(int b=0;b<4;b++)part("Warning stripe",PrimitiveType.Cube,new Vector3(-.7f+b*.45f,.7f,-.14f),new Vector3(.17f,.4f,.03f),9);
                        box.center=new Vector3(0,.45f,0);box.size=new Vector3(1.95f,.9f,.3f);break;
                    case 4:
                        var log=RunnerAvatar.Shape("Fallen trunk",PrimitiveType.Cylinder,root.transform,new Vector3(0,.4f,0),new Vector3(.8f,1,.8f),game.palette[3]);log.transform.localRotation=Quaternion.Euler(0,0,90);
                        part("Broken branch",PrimitiveType.Cube,new Vector3(.3f,.65f,.15f),new Vector3(.2f,.5f,.2f),3);
                        box.center=new Vector3(0,.45f,0);box.size=new Vector3(2,.9f,.8f);break;
                    case 5:
                        part("Truck chassis",PrimitiveType.Cube,new Vector3(0,.65f,0),new Vector3(1.8f,.6f,3),11);
                        part("Cab",PrimitiveType.Cube,new Vector3(0,1.35f,-.35f),new Vector3(1.65f,.8f,1.35f),6);
                        part("Windshield",PrimitiveType.Cube,new Vector3(0,1.45f,-1.04f),new Vector3(1.4f,.5f,.03f),9);
                        part("Cargo",PrimitiveType.Cube,new Vector3(0,1.1f,1),new Vector3(1.5f,.4f,.8f),3);
                        for(int x=-1;x<=1;x+=2)for(int z=-1;z<=1;z+=2){var wheel=RunnerAvatar.Shape("Wheel",PrimitiveType.Cylinder,root.transform,new Vector3(x*.9f,.4f,z),new Vector3(.7f,.13f,.7f),game.palette[9]);wheel.transform.localRotation=Quaternion.Euler(0,0,90);}
                        box.center=new Vector3(0,.9f,0);box.size=new Vector3(2.05f,1.8f,3.1f);break;
                }
                game.obstaclePrefabs[i]=PrefabUtility.SaveAsPrefabAsset(root,"Assets/EndlessRunner/Prefabs/Obstacles/"+names[i]+".prefab");Object.DestroyImmediate(root);
            }
            game.palette[5].EnableKeyword("_EMISSION");game.palette[5].SetColor("_EmissionColor",new Color(.05f,.7f,.6f)*1.5f);EditorUtility.SetDirty(game.palette[5]);
            game.palette[3].color=new Color(.63f,.29f,.14f);EditorUtility.SetDirty(game.palette[3]);
            var urp=UnityEngine.Rendering.Universal.UniversalRenderPipeline.asset;
            if(!urp)throw new System.Exception("URP must be active");
            urp.supportsHDR=true;EditorUtility.SetDirty(urp);
            string profilePath="Assets/EndlessRunner/Materials/DesertLook.asset";
            var profile=AssetDatabase.LoadAssetAtPath<UnityEngine.Rendering.VolumeProfile>(profilePath);
            if(!profile){profile=ScriptableObject.CreateInstance<UnityEngine.Rendering.VolumeProfile>();AssetDatabase.CreateAsset(profile,profilePath);}
            if(!profile.TryGet<UnityEngine.Rendering.Universal.Bloom>(out var bloom)){bloom=profile.Add<UnityEngine.Rendering.Universal.Bloom>();AssetDatabase.AddObjectToAsset(bloom,profile);}
            bloom.intensity.Override(.35f);bloom.threshold.Override(.9f);
            if(!profile.TryGet<UnityEngine.Rendering.Universal.ColorAdjustments>(out var color)){color=profile.Add<UnityEngine.Rendering.Universal.ColorAdjustments>();AssetDatabase.AddObjectToAsset(color,profile);}
            color.contrast.Override(8);color.saturation.Override(8);
            game.lookProfile=profile;EditorUtility.SetDirty(profile);
            EditorUtility.SetDirty(game);EditorSceneManager.MarkSceneDirty(game.gameObject.scene);EditorSceneManager.SaveOpenScenes();AssetDatabase.SaveAssets();
            Debug.Log("ENDLESS_RUNNER_UPGRADE_OK: six obstacle prefabs and existing scene updated");
        }
    }
}
