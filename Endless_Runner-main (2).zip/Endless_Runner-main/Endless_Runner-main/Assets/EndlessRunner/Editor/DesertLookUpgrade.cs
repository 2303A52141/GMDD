using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using TMPro;
using UnityEngine.Rendering.Universal;
namespace EndlessRunner.Editor
{
    public static class DesertLookUpgrade
    {
        static TMP_FontAsset Font(string file,string name)
        {
            string folder="Assets/EndlessRunner/Fonts/";var old=AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(folder+name+".asset");if(old)return old;
            var source=AssetDatabase.LoadAssetAtPath<UnityEngine.Font>(folder+file);var f=TMP_FontAsset.CreateFontAsset(source,90,9,UnityEngine.TextCore.LowLevel.GlyphRenderMode.SDFAA,2048,2048,AtlasPopulationMode.Dynamic);f.name=name;string chars="";for(int i=32;i<127;i++)chars+=(char)i;f.TryAddCharacters(chars,out string missing);f.atlasPopulationMode=AtlasPopulationMode.Static;AssetDatabase.CreateAsset(f,folder+name+".asset");AssetDatabase.AddObjectToAsset(f.material,f);foreach(var tex in f.atlasTextures)AssetDatabase.AddObjectToAsset(tex,f);EditorUtility.SetDirty(f);return f;
        }
        public static string Apply()
        {
            var game=Object.FindFirstObjectByType<RunnerGame>();game.font=Font("Barlow-Regular.ttf","Barlow Body SDF");game.displayFont=Font("BarlowCondensed-SemiBold.ttf","Barlow Display SDF");
            foreach(int index in new[]{0,1,3,11}){var mat=game.palette[index];string path="Assets/EndlessRunner/Materials/Surface"+index+".asset";var tex=AssetDatabase.LoadAssetAtPath<Texture2D>(path);if(!tex){tex=new Texture2D(128,128,TextureFormat.RGB24,true);tex.name="Subtle wind grain";var pixels=new Color[128*128];for(int y=0;y<128;y++)for(int x=0;x<128;x++){float n=Mathf.PerlinNoise(x*.15f,y*.15f);float ripple=Mathf.Sin(x*.28f+Mathf.Sin(y*.07f)*2)*.025f;float v=.87f+n*.1f+ripple;pixels[y*128+x]=new Color(v,v,v);}tex.SetPixels(pixels);tex.Apply();tex.wrapMode=TextureWrapMode.Repeat;tex.anisoLevel=4;AssetDatabase.CreateAsset(tex,path);}mat.SetTexture("_BaseMap",tex);mat.SetTextureScale("_BaseMap",index==1?new Vector2(2,16):new Vector2(4,4));mat.SetFloat("_Smoothness",.08f);EditorUtility.SetDirty(mat);}
            game.palette[0].color=new Color(.83f,.64f,.37f);game.palette[1].color=new Color(.61f,.42f,.24f);game.palette[3].color=new Color(.60f,.28f,.135f);game.palette[11].color=new Color(.76f,.41f,.23f);game.palette[2].color=new Color(.43f,.24f,.135f);
            string skyPath="Assets/EndlessRunner/Materials/DesertSky.mat";var sky=AssetDatabase.LoadAssetAtPath<Material>(skyPath);if(!sky){sky=new Material(Shader.Find("Skybox/Procedural"));AssetDatabase.CreateAsset(sky,skyPath);}sky.SetFloat("_SunSize",.035f);sky.SetFloat("_AtmosphereThickness",1.25f);sky.SetColor("_SkyTint",new Color(.47f,.52f,.58f));sky.SetColor("_GroundColor",new Color(.55f,.39f,.24f));sky.SetFloat("_Exposure",1.05f);game.desertSky=sky;EditorUtility.SetDirty(sky);
            var profile=game.lookProfile;if(profile.TryGet<ColorAdjustments>(out var color)){color.contrast.Override(10);color.saturation.Override(2);EditorUtility.SetDirty(color);}if(profile.TryGet<Bloom>(out var bloom)){bloom.intensity.Override(.16f);EditorUtility.SetDirty(bloom);}QualitySettings.shadows=UnityEngine.ShadowQuality.All;QualitySettings.shadowResolution=UnityEngine.ShadowResolution.High;QualitySettings.shadowDistance=100;
            EditorUtility.SetDirty(game);AssetDatabase.SaveAssets();EditorSceneManager.MarkSceneDirty(game.gameObject.scene);EditorSceneManager.SaveScene(game.gameObject.scene);return "Barlow fonts, textured surfaces, warm sky and restrained grading applied";
        }
    }
}

