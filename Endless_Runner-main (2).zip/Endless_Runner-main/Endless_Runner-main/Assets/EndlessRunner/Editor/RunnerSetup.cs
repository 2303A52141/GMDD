using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using TMPro;

namespace EndlessRunner.Editor
{
    public static class RunnerSetup
    {
        public const string ScenePath="Assets/EndlessRunner/Scenes/EndlessRunner.unity";
        [MenuItem("Endless Runner/Create Game Scene")]
        public static void CreateGame()
        {
            if(EditorApplication.isPlaying)throw new System.InvalidOperationException("Stop Play mode first.");
            if(File.Exists(ScenePath)){EditorSceneManager.SaveOpenScenes();EditorSceneManager.OpenScene(ScenePath);RunnerUpgrade.Apply();return;}
            foreach(var dir in new[]{"Scenes","Materials","Prefabs","Fonts"})Directory.CreateDirectory("Assets/EndlessRunner/"+dir);
            AssetDatabase.Refresh();
            var colors=new[]{new Color(.83f,.61f,.32f),new Color(.69f,.46f,.24f),new Color(.47f,.25f,.13f),new Color(.51f,.32f,.23f),new Color(1,.65f,.06f),new Color(.05f,.9f,.87f),new Color(.08f,.47f,.55f),new Color(.66f,.37f,.20f),new Color(.96f,.86f,.65f),new Color(.10f,.19f,.23f),new Color(.24f,.43f,.20f),new Color(.68f,.32f,.19f)};
            var names=new[]{"Sand","Trail","Rock","Mesa","Gold","Turquoise","Jacket","Skin","Linen","Boots","Cactus","RedSand"};
            var mats=new Material[colors.Length];
            for(int i=0;i<mats.Length;i++)
            {
                string path="Assets/EndlessRunner/Materials/"+names[i]+".mat"; mats[i]=AssetDatabase.LoadAssetAtPath<Material>(path);
                if(!mats[i]) {mats[i]=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(mats[i],path);}
                mats[i].color=colors[i];mats[i].SetFloat("_Smoothness",i==4||i==5?.65f:.1f);if(i==4)mats[i].SetFloat("_Metallic",.6f);EditorUtility.SetDirty(mats[i]);
            }
            var font=AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset");
            if(!font) throw new System.Exception("Bundled TMP font is not imported yet.");
            var player=RunnerAvatar.Make(mats);var prefab=PrefabUtility.SaveAsPrefabAsset(player,"Assets/EndlessRunner/Prefabs/DesertScout.prefab");Object.DestroyImmediate(player);
            // Preserve existing work before opening the new game scene.
            EditorSceneManager.SaveOpenScenes();
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var game=new GameObject("Endless Runner").AddComponent<RunnerGame>();game.palette=mats;game.font=font;game.runnerPrefab=prefab;
            EditorSceneManager.SaveScene(scene,ScenePath);
            EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(ScenePath,true)};
            PlayerSettings.productName="Endless Runner";PlayerSettings.companyName="Desert Trail Games";
            PlayerSettings.defaultScreenWidth=1600;PlayerSettings.defaultScreenHeight=900;PlayerSettings.fullScreenMode=FullScreenMode.FullScreenWindow;
            PlayerSettings.runInBackground=false;
            AssetDatabase.SaveAssets();
            RunnerUpgrade.Apply();
            Debug.Log("ENDLESS_RUNNER_SETUP_OK: scene, materials, font, prefab and build scene saved.");
        }
        [MenuItem("Endless Runner/Build Windows")]
        public static void BuildWindows()
        {
            // OneDrive can mark generated Burst directories read-only. Keep old generated
            // output under Temp and let Unity recreate it; no source assets are touched.
            string burst=Path.GetFullPath("Temp/BurstOutput");
            string tempRoot=Path.GetFullPath("Temp")+Path.DirectorySeparatorChar;
            if(Directory.Exists(burst)&&burst.StartsWith(tempRoot,System.StringComparison.OrdinalIgnoreCase))
            {
                foreach(string entry in Directory.EnumerateFileSystemEntries(burst,"*",SearchOption.AllDirectories))File.SetAttributes(entry,File.GetAttributes(entry)&~FileAttributes.ReadOnly);
                File.SetAttributes(burst,File.GetAttributes(burst)&~FileAttributes.ReadOnly);
                Directory.Move(burst,burst+"-previous-"+System.Guid.NewGuid().ToString("N"));
            }
            Directory.CreateDirectory("Builds/Windows");
            var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{ScenePath},locationPathName="Builds/Windows/Endless Runner.exe",target=BuildTarget.StandaloneWindows64,options=BuildOptions.None});
            File.WriteAllText("Builds/build-result.txt",report.summary.result+" | errors="+report.summary.totalErrors+" | bytes="+report.summary.totalSize);
            if(report.summary.result!=UnityEditor.Build.Reporting.BuildResult.Succeeded)throw new System.Exception("Windows build failed: "+report.summary.result);
            Debug.Log("ENDLESS_RUNNER_BUILD_OK "+report.summary.totalSize);
        }
        public static void QueueBuild(){EditorApplication.update-=BuildQueued;EditorApplication.update+=BuildQueued;}
        static void BuildQueued(){EditorApplication.update-=BuildQueued;BuildWindows();}
    }
}


