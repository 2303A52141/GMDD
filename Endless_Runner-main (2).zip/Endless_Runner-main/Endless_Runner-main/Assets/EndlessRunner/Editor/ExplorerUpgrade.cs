using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using System.IO;
namespace EndlessRunner.Editor
{
    public static class ExplorerUpgrade
    {
        const string Folder="Assets/EndlessRunner/Explorer"; static int meshIndex;
        static Material Mat(string name,Color c){string path=Folder+"/"+name+".mat";var m=AssetDatabase.LoadAssetAtPath<Material>(path);if(!m){m=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(m,path);}m.color=c;m.SetFloat("_Smoothness",.22f);EditorUtility.SetDirty(m);return m;}
        static Transform Joint(string name,Transform p,Vector3 at){var t=new GameObject(name).transform;t.SetParent(p,false);t.localPosition=at;return t;}
        // Elliptical ring profiles model tailored clothing, anatomy and footwear rather than cube limbs.
        static GameObject Part(string name,Transform parent,Vector3 position,Vector3 size,Material mat,float[] profile=null)
        {
            if(profile==null){bool tailored=name.Contains("thigh")||name.Contains("calf")||name.Contains("arm")||name.Contains("sleeve");profile=tailored?new[]{.82f,.93f,1f,.98f,.94f,.87f,.8f}:new[]{0f,.65f,.92f,1f,.95f,.7f,0f};}const int sides=20;var v=new List<Vector3>();var uv=new List<Vector2>();var tr=new List<int>();
            for(int y=0;y<profile.Length;y++)for(int i=0;i<=sides;i++){float a=i*Mathf.PI*2/sides;v.Add(new Vector3(Mathf.Cos(a)*profile[y]*size.x*.5f,(y/(float)(profile.Length-1)-.5f)*size.y,Mathf.Sin(a)*profile[y]*size.z*.5f));uv.Add(new Vector2(i/(float)sides,y/(float)(profile.Length-1)));}
            for(int y=0;y<profile.Length-1;y++)for(int i=0;i<sides;i++){int a=y*(sides+1)+i,b=a+1,c=a+sides+1,d=c+1;tr.Add(a);tr.Add(c);tr.Add(b);tr.Add(b);tr.Add(c);tr.Add(d);}
            int bottom=v.Count;v.Add(new Vector3(0,-size.y*.5f,0));uv.Add(Vector2.zero);int top=v.Count;v.Add(new Vector3(0,size.y*.5f,0));uv.Add(Vector2.one);for(int i=0;i<sides;i++){tr.Add(bottom);tr.Add(i);tr.Add(i+1);int a=(profile.Length-1)*(sides+1)+i;tr.Add(top);tr.Add(a+1);tr.Add(a);}
            var mesh=new Mesh{name=name};mesh.SetVertices(v);mesh.SetUVs(0,uv);mesh.SetTriangles(tr,0);mesh.RecalculateNormals();mesh.RecalculateBounds();string path=Folder+"/Mesh"+(meshIndex++)+".asset";var existing=AssetDatabase.LoadAssetAtPath<Mesh>(path);if(existing){existing.Clear();existing.SetVertices(v);existing.SetUVs(0,uv);existing.SetTriangles(tr,0);existing.RecalculateNormals();existing.RecalculateBounds();EditorUtility.SetDirty(existing);Object.DestroyImmediate(mesh);mesh=existing;}else AssetDatabase.CreateAsset(mesh,path);
            var go=new GameObject(name,typeof(MeshFilter),typeof(MeshRenderer));go.transform.SetParent(parent,false);go.transform.localPosition=position;go.GetComponent<MeshFilter>().sharedMesh=mesh;go.GetComponent<MeshRenderer>().sharedMaterial=mat;return go;
        }
        public static string Apply()
        {
            if(EditorApplication.isPlaying)throw new System.Exception("Stop Play mode first");Directory.CreateDirectory(Folder);AssetDatabase.Refresh();meshIndex=0;
            var skin=Mat("Warm skin",new Color(.68f,.37f,.22f));var hair=Mat("Espresso hair",new Color(.075f,.035f,.02f));var jacket=Mat("Indigo expedition vest",new Color(.08f,.23f,.31f));var cloth=Mat("Ivory woven shirt",new Color(.88f,.78f,.58f));var pants=Mat("Ochre trail trousers",new Color(.36f,.23f,.14f));var boots=Mat("Graphite shoes",new Color(.07f,.075f,.075f));var trim=Mat("Copper trim",new Color(.79f,.32f,.12f));var eye=Mat("Eyes",new Color(.025f,.025f,.02f));var white=Mat("Eye whites",new Color(.92f,.9f,.8f));
            var root=new GameObject("Ari - Dune Pathfinder");var avatar=root.AddComponent<RunnerAvatar>();var cc=root.GetComponent<CharacterController>();cc.height=2.35f;cc.center=new Vector3(0,1.2f,0);cc.radius=.32f;cc.stepOffset=.2f;avatar.lateralSpeed=12;
            avatar.body=Joint("Skeleton",root.transform,Vector3.zero);var body=avatar.body;
            Part("Hips",body,new Vector3(0,.99f,0),new Vector3(.53f,.31f,.32f),pants);
            Part("Fitted expedition vest",body,new Vector3(0,1.44f,0),new Vector3(.68f,.75f,.38f),jacket,new[]{.65f,.72f,.78f,.92f,1f,.9f,.45f});
            Part("Linen undershirt",body,new Vector3(0,1.6f,.19f),new Vector3(.35f,.4f,.04f),cloth,new[]{.72f,.92f,1f,1f,1f,.92f,.72f});
            Part("Neck",body,new Vector3(0,1.88f,0),new Vector3(.22f,.22f,.22f),skin);
            var head=Joint("Head joint",body,new Vector3(0,2.07f,0));
            Part("Sculpted face",head,Vector3.zero,new Vector3(.45f,.53f,.41f),skin,new[]{.25f,.65f,.87f,1f,1f,.85f,.2f});
            Part("Swept hair cap",head,new Vector3(0,.19f,-.025f),new Vector3(.48f,.22f,.43f),hair);
            for(int i=0;i<5;i++){var lockPart=Part("Swept hair lock",head,new Vector3(-.17f+i*.075f,.24f,.09f),new Vector3(.14f,.25f,.29f),hair);lockPart.transform.localRotation=Quaternion.Euler(-25,0,-30);}
            Part("Nose",head,new Vector3(0,-.015f,.217f),new Vector3(.085f,.12f,.1f),skin);
            for(int s=-1;s<=1;s+=2){Part("Ear",head,new Vector3(s*.224f,-.015f,0),new Vector3(.08f,.15f,.1f),skin);Part("Eye white",head,new Vector3(s*.102f,.045f,.19f),new Vector3(.12f,.075f,.05f),white);Part("Iris",head,new Vector3(s*.102f,.044f,.216f),new Vector3(.05f,.058f,.025f),eye);var brow=Part("Eyebrow",head,new Vector3(s*.1f,.105f,.2f),new Vector3(.125f,.035f,.025f),hair);brow.transform.localRotation=Quaternion.Euler(0,0,s*-8);}
            Part("Friendly smile",head,new Vector3(0,-.13f,.19f),new Vector3(.14f,.025f,.025f),hair);
            Part("Trail scarf collar",body,new Vector3(0,1.82f,0),new Vector3(.38f,.13f,.34f),trim);
            var scarf=Joint("Scarf tail",body,new Vector3(-.14f,1.8f,-.18f));Part("Woven scarf tail",scarf,new Vector3(0,-.28f,-.025f),new Vector3(.13f,.62f,.045f),trim);
            Part("Leather daypack",body,new Vector3(0,1.44f,-.28f),new Vector3(.47f,.56f,.24f),pants,new[]{.65f,.92f,1f,1f,.95f,.65f,0f});Part("Daypack flap",body,new Vector3(0,1.61f,-.405f),new Vector3(.4f,.21f,.035f),trim);
            var visual=root.AddComponent<ExplorerVisual>();visual.head=head;visual.scarf=scarf;
            for(int s=-1;s<=1;s+=2){var hip=Joint(s<0?"Left hip":"Right hip",body,new Vector3(s*.17f,.96f,0));Part("Tailored trouser thigh",hip,new Vector3(0,-.23f,0),new Vector3(.27f,.49f,.29f),pants);var knee=Joint("Knee",hip,new Vector3(0,-.44f,0));Part("Trouser calf",knee,new Vector3(0,-.18f,0),new Vector3(.21f,.4f,.24f),pants);Part("Trail shoe",knee,new Vector3(0,-.39f,.075f),new Vector3(.26f,.18f,.46f),boots);Part("Rubber sole",knee,new Vector3(0,-.46f,.085f),new Vector3(.275f,.055f,.47f),cloth);Part("Shoe accent",knee,new Vector3(0,-.35f,.16f),new Vector3(.23f,.05f,.17f),trim);
                var arm=Joint(s<0?"Left shoulder":"Right shoulder",body,new Vector3(s*.38f,1.72f,0));Part("Rolled sleeve",arm,new Vector3(0,-.13f,0),new Vector3(.26f,.31f,.28f),cloth);Part("Upper arm",arm,new Vector3(0,-.29f,0),new Vector3(.18f,.24f,.2f),skin);var elbow=Joint("Elbow",arm,new Vector3(0,-.36f,0));Part("Forearm",elbow,new Vector3(0,-.13f,0),new Vector3(.17f,.29f,.18f),skin);Part("Hand",elbow,new Vector3(0,-.31f,.015f),new Vector3(.18f,.18f,.13f),skin);Part("Wrist wrap",elbow,new Vector3(0,-.245f,0),new Vector3(.185f,.055f,.19f),trim);Part("Shoulder strap",body,new Vector3(s*.21f,1.5f,.19f),new Vector3(.075f,.58f,.045f),pants);
                if(s<0){avatar.leftLeg=hip;avatar.leftArm=arm;visual.leftKnee=knee;visual.leftElbow=elbow;}else{avatar.rightLeg=hip;avatar.rightArm=arm;visual.rightKnee=knee;visual.rightElbow=elbow;}}
            var prefab=PrefabUtility.SaveAsPrefabAsset(root,Folder+"/AriExplorer.prefab");Object.DestroyImmediate(root);var game=Object.FindFirstObjectByType<RunnerGame>();game.runnerPrefab=prefab;EditorUtility.SetDirty(game);EditorSceneManager.MarkSceneDirty(game.gameObject.scene);EditorSceneManager.SaveScene(game.gameObject.scene);AssetDatabase.SaveAssets();return "Original Ari explorer saved: "+meshIndex+" shaped meshes, articulated hip/knee/shoulder/elbow joints";
        }
    }
}



